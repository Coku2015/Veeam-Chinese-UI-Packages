# Veeam ONE Web UI 简体中文补丁

适用于 Veeam ONE Web UI **13.1.0.7034**（Windows）。本补丁在 Veeam ONE Web UI 中注册并启用 `zh-CN`，保留 English、Deutsch、Français 和 日本語。

## 安装

1. 将整个 `VeeamOneWebUiZhCN-13.1.0.7034` 目录复制到 Veeam ONE 服务器。
2. 以管理员身份打开 PowerShell。
3. 执行：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
cd .\windows
.\Install-VeeamOneWebUiZhCN.ps1
```

安装器会验证原始 Web UI 主文件和 `Assets\plugin\plugin.js` 的哈希，在 `%ProgramData%\VeeamWebUiZhCN\VeeamONE-13.1.0.7034\` 中备份原文件，并写入带哈希记录的 manifest。若服务器已升级或文件被其他程序修改，安装器会停止且不覆盖文件。
安装与卸载后，脚本会重启已确认承载 2741 Web API 的 Veeam ONE Reporting Service（`VeeamRSS`），使静态资源立即重新加载。

安装器不会修改 Veeam 原始 `main.1c26fdf6.js`。它会生成带内容指纹的新中文目录和主脚本文件，并仅更新 `index.html` 以引用这些新文件。同时，安装器会把同一份已审核中文目录嵌入 `Assets\plugin\plugin.js`，并为远程 Veeam ONE 分析插件注册 `zh-CN`。因此，VBR 连接 Veeam ONE 后加载的分析页面也能使用简体中文。无论使用服务器主机名、域名或 IP 地址访问，浏览器和常见反向代理都会将新主脚本视为新资源，而不会复用旧主脚本缓存。安装后重新加载 Veeam ONE 页面，然后在登录页或 Web UI 的语言菜单中选择“简体中文”。

没有连接 Veeam ONE 时，VBR 不会请求该远程插件；本补丁对 VBR 的修改仍只作用于 VBR 自身资源，Veeam ONE 插件补丁也不会改变 VBR 的原始文件。插件补丁仅写入 Veeam ONE 服务器的 `Assets\plugin\plugin.js`，并由独立备份和哈希校验保护。

如前方使用 Nginx、Ingress 或 CDN，请将 SPA HTML 响应（包括 `/threat-center` 等回退到 `index.html` 的路由）设为 `Cache-Control: no-cache, must-revalidate`，并在安装或卸载时清除该 HTML 缓存。带内容指纹的静态 JS 可以长期缓存。这样即使变更服务器 IP、主机名或域名，也不影响补丁加载。

如果之前已经安装过旧版本补丁，请先使用新版目录中的卸载脚本恢复原文件，再重新执行安装脚本。安装完成后，首次从 VBR 打开分析页面时同时对 VBR 和 Veeam ONE 页面执行一次硬刷新，以清除可能被反向代理缓存的旧 `plugin.js`。

## 卸载与恢复

以管理员身份在同一目录执行：

```powershell
.\Uninstall-VeeamOneWebUiZhCN.ps1
```

卸载器会先验证当前文件确实由本补丁写入，再验证备份哈希，最后恢复原始文件。若文件已被升级或修改，卸载器会停止，不会覆盖未知文件。

## 包内容

- `windows/Install-VeeamOneWebUiZhCN.ps1`：安全安装器
- `windows/Uninstall-VeeamOneWebUiZhCN.ps1`：哈希校验卸载器
- `windows/assets/veeam-one-zh-CN-catalog.js`：由已审核 PO 生成的中文目录
- `windows/assets/veeam-one-zh-CN-plugin-catalog.js`：嵌入远程分析插件的同源中文目录

Veeam ONE 服务器为 Windows 部署，本版本不提供 Linux 安装脚本。`full.zip` 仅包含同一 Windows 补丁及文档。

## 来源与校验

- 产品：Veeam ONE Web UI
- Build：13.1.0.7034
- 资源目录：`Veeam ONE Reporter Server\Assets`（主 JS 位于其 `static\js` 子目录）
- 主资源：`main.1c26fdf6.js`
- 分析插件资源：`plugin\plugin.js`（原始 SHA256：`a7a8f439cade361c2704362a3babd04c27e38200996253dcc3ec9bba27488939`）
- 源资源 SHA256：`abdbc07ad231bbce464b734213e0e515121bc3bf80959a25301b49959199ce39`
- 中文目录来自：`review/veeam-one-webui-13.1.0.7034-zh-CN-review.po`
- 插件提取记录：`catalog/veeam-one-plugin-13.1.0.7034-zh-CN-review.json`；未发现新的待翻译源字符串，4380 个插件条目与 Veeam ONE 主目录完全复用。
