#!/usr/bin/env bash
set -euo pipefail

BUILD="13.1.0.411"
BACKUP_ROOT="/var/lib/veeam-webui-zh-cn/${BUILD}"
MANIFEST_PATH="${BACKUP_ROOT}/manifest.env"

die() {
  echo "ERROR: $*" >&2
  exit 1
}

sha256_file() {
  sha256sum "$1" | awk '{print tolower($1)}'
}

if [[ "${EUID}" -ne 0 ]]; then
  die "Run this script as root: sudo ./uninstall-veeam-webui-zh-cn.sh"
fi

command -v sha256sum >/dev/null 2>&1 || die "Required command not found: sha256sum"
command -v awk >/dev/null 2>&1 || die "Required command not found: awk"

[[ -f "${MANIFEST_PATH}" ]] || die "Package manifest was not found: ${MANIFEST_PATH}"

# shellcheck disable=SC1090
source "${MANIFEST_PATH}"

[[ -f "${HTML_PATH}" ]] || die "Current index.html was not found: ${HTML_PATH}"
[[ -f "${INDEX_PATH}" ]] || die "Current main Web UI bundle was not found: ${INDEX_PATH}"
[[ -f "${PLUGIN_PATH}" ]] || die "Current Web UI plugin bundle was not found: ${PLUGIN_PATH}"
[[ -f "${VDP_PLUGIN_PATH}" ]] || die "Current Web UI VDP plugin bundle was not found: ${VDP_PLUGIN_PATH}"
[[ -f "${BACKUP_HTML_PATH}" ]] || die "Backup was not found: ${BACKUP_HTML_PATH}"
[[ -f "${BACKUP_INDEX_PATH}" ]] || die "Backup was not found: ${BACKUP_INDEX_PATH}"
[[ -f "${BACKUP_PLUGIN_PATH}" ]] || die "Backup was not found: ${BACKUP_PLUGIN_PATH}"
[[ -f "${BACKUP_VDP_PLUGIN_PATH}" ]] || die "Backup was not found: ${BACKUP_VDP_PLUGIN_PATH}"

RESTORE_AHV_PLUGIN="no"
if [[ -n "${AHV_PLUGIN_PATH:-}" ||
      -n "${BACKUP_AHV_PLUGIN_PATH:-}" ||
      -n "${PATCHED_AHV_PLUGIN_SHA256:-}" ||
      -n "${ORIGINAL_AHV_PLUGIN_SHA256:-}" ]]; then
  [[ -f "${AHV_PLUGIN_PATH}" ]] || die "Current AHV extension plugin bundle was not found: ${AHV_PLUGIN_PATH}"
  [[ -f "${BACKUP_AHV_PLUGIN_PATH}" ]] || die "Backup was not found: ${BACKUP_AHV_PLUGIN_PATH}"
  RESTORE_AHV_PLUGIN="yes"
fi

RESTORE_PVE_PLUGIN="no"
if [[ -n "${PVE_PLUGIN_PATH:-}" ||
      -n "${BACKUP_PVE_PLUGIN_PATH:-}" ||
      -n "${PATCHED_PVE_PLUGIN_SHA256:-}" ||
      -n "${ORIGINAL_PVE_PLUGIN_SHA256:-}" ]]; then
  [[ -f "${PVE_PLUGIN_PATH}" ]] || die "Current PVE extension plugin bundle was not found: ${PVE_PLUGIN_PATH}"
  [[ -f "${BACKUP_PVE_PLUGIN_PATH}" ]] || die "Backup was not found: ${BACKUP_PVE_PLUGIN_PATH}"
  RESTORE_PVE_PLUGIN="yes"
fi

RESTORE_LOGIN_SELECTOR="no"
if [[ -n "${LOGIN_SELECTOR_PATH:-}" ||
      -n "${BACKUP_LOGIN_SELECTOR_PATH:-}" ||
      -n "${PATCHED_LOGIN_SELECTOR_SHA256:-}" ||
      -n "${ORIGINAL_LOGIN_SELECTOR_SHA256:-}" ]]; then
  [[ -f "${LOGIN_SELECTOR_PATH}" ]] || die "Current login language selector was not found: ${LOGIN_SELECTOR_PATH}"
  [[ -f "${BACKUP_LOGIN_SELECTOR_PATH}" ]] || die "Backup was not found: ${BACKUP_LOGIN_SELECTOR_PATH}"
  RESTORE_LOGIN_SELECTOR="yes"
fi

if [[ "$(sha256_file "${HTML_PATH}")" != "${PATCHED_HTML_SHA256}" ||
      "$(sha256_file "${INDEX_PATH}")" != "${PATCHED_INDEX_SHA256}" ||
      "$(sha256_file "${PLUGIN_PATH}")" != "${PATCHED_PLUGIN_SHA256}" ||
      "$(sha256_file "${VDP_PLUGIN_PATH}")" != "${PATCHED_VDP_PLUGIN_SHA256}" ]]; then
  die "Current Web UI files were not written by this package. The server may have been upgraded or modified. No changes were made."
fi
if [[ "${RESTORE_AHV_PLUGIN}" == "yes" &&
      "$(sha256_file "${AHV_PLUGIN_PATH}")" != "${PATCHED_AHV_PLUGIN_SHA256}" ]]; then
  die "Current AHV extension plugin file was not written by this package. No changes were made."
fi
if [[ "${RESTORE_PVE_PLUGIN}" == "yes" &&
      "$(sha256_file "${PVE_PLUGIN_PATH}")" != "${PATCHED_PVE_PLUGIN_SHA256}" ]]; then
  die "Current PVE extension plugin file was not written by this package. No changes were made."
fi
if [[ "${RESTORE_LOGIN_SELECTOR}" == "yes" &&
      "$(sha256_file "${LOGIN_SELECTOR_PATH}")" != "${PATCHED_LOGIN_SELECTOR_SHA256}" ]]; then
  die "Current Web UI files were not written by this package. The server may have been upgraded or modified. No changes were made."
fi

if [[ -f "${NATIVE_ASSET_PATH}" && "$(sha256_file "${NATIVE_ASSET_PATH}")" != "${NATIVE_ASSET_SHA256}" ]]; then
  die "Current native Chinese asset was not written by this package. No changes were made."
fi
if [[ -f "${CATALOG_ASSET_PATH}" && "$(sha256_file "${CATALOG_ASSET_PATH}")" != "${CATALOG_ASSET_SHA256}" ]]; then
  die "Current Chinese catalog asset was not written by this package. No changes were made."
fi

TMP_HTML="${HTML_PATH}.veeam-zh-cn-restore.$$"
TMP_INDEX="${INDEX_PATH}.veeam-zh-cn-restore.$$"
TMP_PLUGIN="${PLUGIN_PATH}.veeam-zh-cn-restore.$$"
TMP_VDP_PLUGIN="${VDP_PLUGIN_PATH}.veeam-zh-cn-restore.$$"
TMP_AHV_PLUGIN="${AHV_PLUGIN_PATH:-/tmp/ahv-plugin.js}.veeam-zh-cn-restore.$$"
TMP_PVE_PLUGIN="${PVE_PLUGIN_PATH:-/tmp/pve-plugin.js}.veeam-zh-cn-restore.$$"
TMP_LOGIN_SELECTOR="${LOGIN_SELECTOR_PATH:-/tmp/languageSelector.js}.veeam-zh-cn-restore.$$"
cleanup() {
  rm -f "${TMP_HTML}" "${TMP_INDEX}" "${TMP_PLUGIN}" "${TMP_VDP_PLUGIN}" "${TMP_AHV_PLUGIN}" "${TMP_PVE_PLUGIN}" "${TMP_LOGIN_SELECTOR}"
}
trap cleanup EXIT

cp -p "${BACKUP_HTML_PATH}" "${TMP_HTML}"
cp -p "${BACKUP_INDEX_PATH}" "${TMP_INDEX}"
cp -p "${BACKUP_PLUGIN_PATH}" "${TMP_PLUGIN}"
cp -p "${BACKUP_VDP_PLUGIN_PATH}" "${TMP_VDP_PLUGIN}"
if [[ "${RESTORE_AHV_PLUGIN}" == "yes" ]]; then
  cp -p "${BACKUP_AHV_PLUGIN_PATH}" "${TMP_AHV_PLUGIN}"
fi
if [[ "${RESTORE_PVE_PLUGIN}" == "yes" ]]; then
  cp -p "${BACKUP_PVE_PLUGIN_PATH}" "${TMP_PVE_PLUGIN}"
fi
if [[ "${RESTORE_LOGIN_SELECTOR}" == "yes" ]]; then
  cp -p "${BACKUP_LOGIN_SELECTOR_PATH}" "${TMP_LOGIN_SELECTOR}"
fi
mv -f "${TMP_HTML}" "${HTML_PATH}"
mv -f "${TMP_INDEX}" "${INDEX_PATH}"
mv -f "${TMP_PLUGIN}" "${PLUGIN_PATH}"
mv -f "${TMP_VDP_PLUGIN}" "${VDP_PLUGIN_PATH}"
if [[ "${RESTORE_AHV_PLUGIN}" == "yes" ]]; then
  mv -f "${TMP_AHV_PLUGIN}" "${AHV_PLUGIN_PATH}"
fi
if [[ "${RESTORE_PVE_PLUGIN}" == "yes" ]]; then
  mv -f "${TMP_PVE_PLUGIN}" "${PVE_PLUGIN_PATH}"
fi
if [[ "${RESTORE_LOGIN_SELECTOR}" == "yes" ]]; then
  mv -f "${TMP_LOGIN_SELECTOR}" "${LOGIN_SELECTOR_PATH}"
fi
trap - EXIT

rm -f "${NATIVE_ASSET_PATH}" "${CATALOG_ASSET_PATH}"

if [[ "$(sha256_file "${HTML_PATH}")" != "${ORIGINAL_HTML_SHA256}" ||
      "$(sha256_file "${INDEX_PATH}")" != "${ORIGINAL_INDEX_SHA256}" ||
      "$(sha256_file "${PLUGIN_PATH}")" != "${ORIGINAL_PLUGIN_SHA256}" ||
      "$(sha256_file "${VDP_PLUGIN_PATH}")" != "${ORIGINAL_VDP_PLUGIN_SHA256}" ]]; then
  die "Restored Web UI file hashes are unexpected. Keep the backup directory and stop: ${BACKUP_ROOT}"
fi
if [[ "${RESTORE_AHV_PLUGIN}" == "yes" &&
      "$(sha256_file "${AHV_PLUGIN_PATH}")" != "${ORIGINAL_AHV_PLUGIN_SHA256}" ]]; then
  die "Restored AHV extension plugin file hash is unexpected. Keep the backup directory and stop: ${BACKUP_ROOT}"
fi
if [[ "${RESTORE_PVE_PLUGIN}" == "yes" &&
      "$(sha256_file "${PVE_PLUGIN_PATH}")" != "${ORIGINAL_PVE_PLUGIN_SHA256}" ]]; then
  die "Restored PVE extension plugin file hash is unexpected. Keep the backup directory and stop: ${BACKUP_ROOT}"
fi
if [[ "${RESTORE_LOGIN_SELECTOR}" == "yes" &&
      "$(sha256_file "${LOGIN_SELECTOR_PATH}")" != "${ORIGINAL_LOGIN_SELECTOR_SHA256}" ]]; then
  die "Restored Web UI file hashes are unexpected. Keep the backup directory and stop: ${BACKUP_ROOT}"
fi

rm -rf "${BACKUP_ROOT}"
echo "Veeam Web UI Simplified Chinese package uninstalled. Original file hashes were verified."
