[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Assert-Administrator {
    $p = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script from an elevated PowerShell session.'
    }
}

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

Assert-Administrator

$build = '13.1.0.411'
$webRoot = Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\BackupWebUI'
$htmlPath = Join-Path $webRoot 'index.html'
$indexPath = Join-Path $webRoot 'assets\index-BJPSD5I9.js'
$pluginPath = Join-Path $webRoot 'plugin\plugin.js'
$vdpPluginPath = Join-Path $webRoot 'plugin\vdpPlugin.js'
$loginSelectorPath = Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\Backup\wwwroot\oauth\static\lib\languageSelector.js'
$nativeAssetPath = Join-Path $webRoot 'assets\veeam-zh-CN-native.js'
$catalogAssetPath = Join-Path $webRoot 'assets\veeam-zh-CN-catalog.js'
$backupRoot = Join-Path $env:ProgramData "VeeamWebUiZhCN\$build"
$backupHtmlPath = Join-Path $backupRoot 'index.html.original'
$backupIndexPath = Join-Path $backupRoot 'index-BJPSD5I9.js.original'
$backupPluginPath = Join-Path $backupRoot 'plugin.js.original'
$backupVdpPluginPath = Join-Path $backupRoot 'vdpPlugin.js.original'
$backupLoginSelectorPath = Join-Path $backupRoot 'languageSelector.js.original'
$manifestPath = Join-Path $backupRoot 'manifest.json'

if (-not (Test-Path -LiteralPath $manifestPath) -or
    -not (Test-Path -LiteralPath $backupHtmlPath) -or
    -not (Test-Path -LiteralPath $backupIndexPath) -or
    -not (Test-Path -LiteralPath $backupPluginPath) -or
    -not (Test-Path -LiteralPath $backupVdpPluginPath) -or
    -not (Test-Path -LiteralPath $backupLoginSelectorPath)) {
    throw 'Package backup or manifest was not found. No files were changed.'
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $manifest.PatchedPluginSha256 -or -not $manifest.PatchedVdpPluginSha256) {
    throw 'This manifest belongs to an older package. Use the matching older uninstall script. No files were changed.'
}

if ((Get-Sha256 $htmlPath) -ne $manifest.PatchedHtmlSha256 -or
    (Get-Sha256 $indexPath) -ne $manifest.PatchedIndexSha256 -or
    (Get-Sha256 $pluginPath) -ne $manifest.PatchedPluginSha256 -or
    (Get-Sha256 $vdpPluginPath) -ne $manifest.PatchedVdpPluginSha256 -or
    (Get-Sha256 $loginSelectorPath) -ne $manifest.PatchedLoginSelectorSha256) {
    throw 'Current Web UI files were not written by this package. The server may have been upgraded or modified. No files were changed.'
}
if ((Test-Path -LiteralPath $nativeAssetPath) -and ((Get-Sha256 $nativeAssetPath) -ne $manifest.NativeAssetSha256)) {
    throw 'Current native Chinese asset was not written by this package. No files were changed.'
}
if ((Test-Path -LiteralPath $catalogAssetPath) -and ((Get-Sha256 $catalogAssetPath) -ne $manifest.CatalogAssetSha256)) {
    throw 'Current Chinese catalog asset was not written by this package. No files were changed.'
}

$tempHtml = "$htmlPath.veeam-zh-cn-restore"
$tempIndex = "$indexPath.veeam-zh-cn-restore"
$tempPlugin = "$pluginPath.veeam-zh-cn-restore"
$tempVdpPlugin = "$vdpPluginPath.veeam-zh-cn-restore"
$tempLoginSelector = "$loginSelectorPath.veeam-zh-cn-restore"
Copy-Item -LiteralPath $backupHtmlPath -Destination $tempHtml -Force
Copy-Item -LiteralPath $backupIndexPath -Destination $tempIndex -Force
Copy-Item -LiteralPath $backupPluginPath -Destination $tempPlugin -Force
Copy-Item -LiteralPath $backupVdpPluginPath -Destination $tempVdpPlugin -Force
Copy-Item -LiteralPath $backupLoginSelectorPath -Destination $tempLoginSelector -Force
Move-Item -LiteralPath $tempHtml -Destination $htmlPath -Force
Move-Item -LiteralPath $tempIndex -Destination $indexPath -Force
Move-Item -LiteralPath $tempPlugin -Destination $pluginPath -Force
Move-Item -LiteralPath $tempVdpPlugin -Destination $vdpPluginPath -Force
Move-Item -LiteralPath $tempLoginSelector -Destination $loginSelectorPath -Force

if (Test-Path -LiteralPath $nativeAssetPath) { Remove-Item -LiteralPath $nativeAssetPath -Force }
if (Test-Path -LiteralPath $catalogAssetPath) { Remove-Item -LiteralPath $catalogAssetPath -Force }

if ((Get-Sha256 $htmlPath) -ne $manifest.OriginalHtmlSha256 -or
    (Get-Sha256 $indexPath) -ne $manifest.OriginalIndexSha256 -or
    (Get-Sha256 $pluginPath) -ne $manifest.OriginalPluginSha256 -or
    (Get-Sha256 $vdpPluginPath) -ne $manifest.OriginalVdpPluginSha256 -or
    (Get-Sha256 $loginSelectorPath) -ne $manifest.OriginalLoginSelectorSha256) {
    throw 'Restored Web UI file hashes are unexpected. Keep the backup directory and stop.'
}

Remove-Item -LiteralPath $backupRoot -Recurse -Force
Write-Host 'Veeam Web UI Simplified Chinese package uninstalled. Original file hashes were verified.' -ForegroundColor Green
