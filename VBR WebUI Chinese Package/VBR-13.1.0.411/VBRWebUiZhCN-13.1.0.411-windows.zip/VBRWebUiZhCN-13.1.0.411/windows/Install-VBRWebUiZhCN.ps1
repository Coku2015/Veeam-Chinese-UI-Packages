[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Assert-Administrator {
    $p = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script from an elevated PowerShell session.'
    }
}

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false))
}

function Replace-Required([string]$Text, [string]$Needle, [string]$Replacement, [string]$Name) {
    if (-not $Text.Contains($Needle)) {
        throw "Expected $Name fragment was not found. No files were changed."
    }
    $Text.Replace($Needle, $Replacement)
}

function Js-Quote([string]$Value) {
    ([char]96) + $Value + ([char]96)
}

function Js-Language([string]$Iso, [string]$Title, [string]$Resource) {
    '{iso:' + (Js-Quote $Iso) + ',title:' + (Js-Quote $Title) + ',flag:' + (Js-Quote '') + ',resources:' + $Resource + '}'
}

function Unicode-String([int[]]$CodePoints) {
    -join ($CodePoints | ForEach-Object { [char]$_ })
}
function Replace-OnceRegex([string]$Text, [string]$Pattern, [string]$Replacement, [string]$Name) {
    $matches = [regex]::Matches($Text, $Pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if ($matches.Count -ne 1) { throw "Expected $Name fragment was not found exactly once. No files were changed." }
    [regex]::Replace($Text, $Pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement }, 1)
}

Assert-Administrator

$build = '13.1.0.411'
$expectedHtmlHash = '76dc7dbf81e9e42720d1842cd556d5e880d29f09ab8ba3235caef31553dc1513'
$expectedIndexHash = 'bcaa9af5c11f9818009b893a9b6da39f1d1be3efe05bb94bb48ad9cc05a893c4'
$expectedPluginHash = 'd356026d5fa92cfc56e24fdb1d58e6959f4a16c09685ba5ea95272d8b60cdbce'
$expectedVdpPluginHash = 'aca08c17fe891429dd7b0b405264e939ed4af86bd15c2171c6028c7685769d35'
$nativeOnlyHtmlHash = '27e5ebb87ae0db70bb00c3fddac07285c48dc9b6f89f6a8cc7a332925cacd0ca'
$nativeOnlyIndexHash = '16088cd2afc8346b1229d2b278dcd95d0be3c32db51e25c1969b87d46fc6ef39'
$localeKey = 'veeamWebUiZhNativeLocale'

$webRoot = Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\BackupWebUI'
$htmlPath = Join-Path $webRoot 'index.html'
$indexPath = Join-Path $webRoot 'assets\index-BJPSD5I9.js'
$pluginPath = Join-Path $webRoot 'plugin\plugin.js'
$vdpPluginPath = Join-Path $webRoot 'plugin\vdpPlugin.js'
$loginSelectorPath = Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\Backup\wwwroot\oauth\static\lib\languageSelector.js'
$nativeAssetPath = Join-Path $webRoot 'assets\veeam-zh-CN-native.js'
$catalogAssetPath = Join-Path $webRoot 'assets\veeam-zh-CN-catalog.js'
$sourceNativeAssetPath = Join-Path $PSScriptRoot 'assets\veeam-zh-CN-native.js'
$sourceCatalogAssetPath = Join-Path $PSScriptRoot 'assets\veeam-zh-CN-catalog.js'

$backupRoot = Join-Path $env:ProgramData "VeeamWebUiZhCN\$build"
$backupHtmlPath = Join-Path $backupRoot 'index.html.original'
$backupIndexPath = Join-Path $backupRoot 'index-BJPSD5I9.js.original'
$backupPluginPath = Join-Path $backupRoot 'plugin.js.original'
$backupVdpPluginPath = Join-Path $backupRoot 'vdpPlugin.js.original'
$backupLoginSelectorPath = Join-Path $backupRoot 'languageSelector.js.original'
$manifestPath = Join-Path $backupRoot 'manifest.json'
$legacyLoginBackupRoot = Join-Path $env:ProgramData "VeeamWebUiZhNativePreview\$build"
$legacyLoginManifestPath = Join-Path $legacyLoginBackupRoot 'login-selector-manifest.json'
$legacyLoginBackupPath = Join-Path $legacyLoginBackupRoot 'languageSelector.js.original'

$moduleTag = '<script type="module" crossorigin src="./assets/index-BJPSD5I9.js"></script>'
$catalogTag = '<script src="./assets/veeam-zh-CN-catalog.js?v=99f6742c826c3e0b"></script>'
$nativeTag = '<script src="./assets/veeam-zh-CN-native.js?v=b623b0ca2adff0b4"></script>'
$patchedModuleTag = '<script type="module" crossorigin src="./assets/index-BJPSD5I9.js?v=veeam-zh-cn-analytics-r3"></script>'

if (-not (Test-Path -LiteralPath $htmlPath) -or -not (Test-Path -LiteralPath $indexPath)) {
    throw "Veeam Web UI files were not found. Expected directory: $webRoot"
}
if (-not (Test-Path -LiteralPath $pluginPath) -or -not (Test-Path -LiteralPath $vdpPluginPath)) {
    throw "Veeam Web UI plugin files were not found. Expected directory: $(Join-Path $webRoot 'plugin')"
}
if (-not (Test-Path -LiteralPath $loginSelectorPath)) {
    throw "Veeam OAuth login language selector was not found: $loginSelectorPath"
}
if (-not (Test-Path -LiteralPath $sourceNativeAssetPath) -or -not (Test-Path -LiteralPath $sourceCatalogAssetPath)) {
    throw 'Package Chinese assets are incomplete.'
}

$serviceExe = Join-Path $env:ProgramFiles 'Veeam\Backup and Replication\Backup\Veeam.Backup.Service.exe'
if (Test-Path -LiteralPath $serviceExe) {
    $version = (Get-Item -LiteralPath $serviceExe).VersionInfo.ProductVersion
    if ($version -notlike "$build*") {
        throw "This package supports VBR $build only. Detected: $version"
    }
}

$htmlHash = Get-Sha256 $htmlPath
$indexHash = Get-Sha256 $indexPath
$pluginHash = Get-Sha256 $pluginPath
$vdpPluginHash = Get-Sha256 $vdpPluginPath
$loginSelectorHash = Get-Sha256 $loginSelectorPath
$sourceNativeHash = Get-Sha256 $sourceNativeAssetPath
$sourceCatalogHash = Get-Sha256 $sourceCatalogAssetPath

if (Test-Path -LiteralPath $manifestPath) {
    $existing = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $existing.PatchedPluginSha256 -or -not $existing.PatchedVdpPluginSha256) {
        throw 'An older package manifest was found. Uninstall the old package first, then install this package.'
    }
    $assetsMatch = (Test-Path -LiteralPath $nativeAssetPath) -and (Test-Path -LiteralPath $catalogAssetPath) -and
        ((Get-Sha256 $nativeAssetPath) -eq $existing.NativeAssetSha256) -and
        ((Get-Sha256 $catalogAssetPath) -eq $existing.CatalogAssetSha256)
    if ($htmlHash -eq $existing.PatchedHtmlSha256 -and
        $indexHash -eq $existing.PatchedIndexSha256 -and
        $pluginHash -eq $existing.PatchedPluginSha256 -and
        $vdpPluginHash -eq $existing.PatchedVdpPluginSha256 -and
        (Get-Sha256 $loginSelectorPath) -eq $existing.PatchedLoginSelectorSha256 -and
        $assetsMatch) {
        Write-Host 'Veeam Web UI Simplified Chinese package is already installed. No changes were made.' -ForegroundColor Yellow
        exit 0
    }
    throw 'An existing package manifest was found, but current Web UI files do not match it. No changes were made.'
}

if ((Test-Path -LiteralPath $legacyLoginManifestPath) -and (Test-Path -LiteralPath $legacyLoginBackupPath)) {
    $legacyLogin = Get-Content -LiteralPath $legacyLoginManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($loginSelectorHash -eq $legacyLogin.PatchedSha256) {
        $tempLegacyLoginRestore = "$loginSelectorPath.veeam-zh-legacy-login-restore"
        Copy-Item -LiteralPath $legacyLoginBackupPath -Destination $tempLegacyLoginRestore -Force
        Move-Item -LiteralPath $tempLegacyLoginRestore -Destination $loginSelectorPath -Force
        $loginSelectorHash = Get-Sha256 $loginSelectorPath
        Write-Host 'Restored older login selector preview before installing this package.' -ForegroundColor Yellow
    }
}

if ($htmlHash -eq $nativeOnlyHtmlHash -and $indexHash -eq $nativeOnlyIndexHash) {
    throw 'An older native preview appears to be installed. Uninstall the old preview first, then install this package.'
}

if ($htmlHash -ne $expectedHtmlHash -or
    $indexHash -ne $expectedIndexHash -or
    $pluginHash -ne $expectedPluginHash -or
    $vdpPluginHash -ne $expectedVdpPluginHash) {
    throw 'Current Web UI hashes do not match VBR 13.1.0.411. The server may have been upgraded, patched, or may still have an older preview installed. No changes were made.'
}

if ((Test-Path -LiteralPath $nativeAssetPath) -and ((Get-Sha256 $nativeAssetPath) -ne $sourceNativeHash)) {
    throw "A different native Chinese asset already exists: $nativeAssetPath. No changes were made."
}
if ((Test-Path -LiteralPath $catalogAssetPath) -and ((Get-Sha256 $catalogAssetPath) -ne $sourceCatalogHash)) {
    throw "A different Chinese catalog asset already exists: $catalogAssetPath. No changes were made."
}

$en = Js-Language 'en' 'English' 'qre'
$ja = Js-Language 'ja' (Unicode-String @(0x65E5, 0x672C, 0x8A9E)) 'Gre'
$de = Js-Language 'de' 'Deutsch' 'Kre'
$fr = Js-Language 'fr' ('Fran' + [char]0x00E7 + 'ais') 'uie'
$zh = Js-Language 'zh-CN' (Unicode-String @(0x7B80, 0x4F53, 0x4E2D, 0x6587)) 'globalThis.__VeeamWebUiZhCatalog'

$oldRegistry = 'im=[' + $en + ',' + $ja + ',' + $de + ',' + $fr + ']'
$newRegistry = 'im=[' + $en + ',' + $ja + ',' + $de + ',' + $fr + ',' + $zh + ']'
$qKey = Js-Quote $localeKey
$qZh = Js-Quote 'zh-CN'
$qEn = Js-Quote 'en'
$qPluginKey = Js-Quote 'localization:language'
$oldStorage = 'Dfe=class{constructor(e){this.localizationService=e,this.getValue=()=>this.localizationService.language,this.setValue=e=>{},this.clear=()=>{}}}'
$newStorage = 'Dfe=class{constructor(e){this.localizationService=e,this.getValue=()=>localStorage.getItem(' + $qKey + ')??this.localizationService.language,this.setValue=e=>{e===' + $qZh + '?localStorage.setItem(' + $qKey + ',e):localStorage.removeItem(' + $qKey + ')},this.clear=()=>{localStorage.removeItem(' + $qKey + ')}}}'
$oldSetter = 'Ofe=class e{static{this.create=t=>new e(t)}constructor(e){this.userSettingsStore=e,this.setLanguage=async({newLanguage:e,abortSignal:t})=>{await this.userSettingsStore.setLanguage({lang:e,abortSignal:t})}}get language(){return this.userSettingsStore.getValueOrDefault().lang}}'
$newSetter = 'Ofe=class e{static{this.create=t=>new e(t)}constructor(e){this.userSettingsStore=e,this.setLanguage=async({newLanguage:e,abortSignal:t})=>{localStorage.setItem(' + $qPluginKey + ',JSON.stringify(e));if(e===' + $qZh + '){localStorage.setItem(' + $qKey + ',e);await this.userSettingsStore.setLanguage({lang:' + $qEn + ',abortSignal:t});globalThis.location?.reload?.();return;}localStorage.removeItem(' + $qKey + ');await this.userSettingsStore.setLanguage({lang:e,abortSignal:t})}}get language(){return this.userSettingsStore.getValueOrDefault().lang}}'
$oldAnalyticsPresenter = 'lye=class{constructor(e,t){this.controller=e,this.localizationService=t}showDashboards(e,t){this.controller.renderDashboards(e,t,this.localizationService.language)}showReports(e,t){this.controller.renderReports(e,t,this.localizationService.language)}get isAlarmOverviewSupported(){return this.controller.version===ls.v2}showAlarmOverview(e,t){this.controller.version===ls.v2&&this.controller.renderAlarms(e,t,this.localizationService.language)}}'
$newAnalyticsPresenter = 'lye=class{constructor(e,t){this.controller=e,this.localizationService=t,this.getLanguage=()=>localStorage.getItem(`veeamWebUiZhNativeLocale`)===`zh-CN`?`zh-CN`:this.localizationService.language}showDashboards(e,t){this.controller.renderDashboards(e,t,this.getLanguage())}showReports(e,t){this.controller.renderReports(e,t,this.getLanguage())}get isAlarmOverviewSupported(){return this.controller.version===ls.v2}showAlarmOverview(e,t){this.controller.version===ls.v2&&this.controller.renderAlarms(e,t,this.getLanguage())}}'
$oldVeeamOnePluginUrl = 'this.getUrlToBundle=e=>(e.endsWith(`/`)?e:e+`/`)+`plugin/plugin.js`'
$newVeeamOnePluginUrl = 'this.getUrlToBundle=e=>(e.endsWith(`/`)?e:e+`/`)+`plugin/plugin.js?veeam-zh-cn-analytics-r3`'

$html = Get-Content -LiteralPath $htmlPath -Raw -Encoding UTF8
if (-not $html.Contains($moduleTag)) {
    throw 'Expected Web UI module script tag was not found. No files were changed.'
}
$index = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8
$index = Replace-Required $index $oldRegistry $newRegistry 'language registry'
$index = Replace-Required $index $oldStorage $newStorage 'language local storage'
$index = Replace-Required $index $oldSetter $newSetter 'language persistence'
$index = Replace-Required $index $oldAnalyticsPresenter $newAnalyticsPresenter 'Veeam ONE analytics language forwarding'
$index = Replace-Required $index $oldVeeamOnePluginUrl $newVeeamOnePluginUrl 'Veeam ONE plugin cache-busting URL'

function Add-PluginLanguage([string]$Text, [string]$Name) {
    $zhEntryText = 'iso:`zh-CN`,title:`简体中文`,flag:``,resources:globalThis.__VeeamWebUiZhCatalog'
    if ($Text.Contains($zhEntryText)) {
        throw "$Name already contains the Chinese plugin language entry."
    }
    $marker = '=[{iso:`en`,title:`English`,flag:``,resources:{'
    $markerPos = $Text.IndexOf($marker, [System.StringComparison]::Ordinal)
    if ($markerPos -lt 0) {
        throw "Expected plugin language registry fragment was not found in $Name."
    }
    $start = $Text.IndexOf('[', $markerPos)
    $depth = 0
    $quote = [char]0
    $escaped = $false
    $end = -1
    for ($i = $start; $i -lt $Text.Length; $i++) {
        $ch = $Text[$i]
        if ($quote -ne [char]0) {
            if ($escaped) {
                $escaped = $false
            } elseif ($ch -eq '\') {
                $escaped = $true
            } elseif ($ch -eq $quote) {
                $quote = [char]0
            }
            continue
        }
        if ($ch -eq '"' -or $ch -eq "'" -or $ch -eq '`') {
            $quote = $ch
        } elseif ($ch -eq '[') {
            $depth++
        } elseif ($ch -eq ']') {
            $depth--
            if ($depth -eq 0) {
                $end = $i
                break
            }
        }
    }
    if ($end -lt 0) {
        throw "Could not find the end of plugin language registry in $Name."
    }
    $zhEntry = ',{iso:`zh-CN`,title:`简体中文`,flag:``,resources:globalThis.__VeeamWebUiZhCatalog}'
    $Text.Substring(0, $end) + $zhEntry + $Text.Substring($end)
}

$plugin = Add-PluginLanguage (Get-Content -LiteralPath $pluginPath -Raw -Encoding UTF8) 'plugin.js'
$vdpPlugin = Add-PluginLanguage (Get-Content -LiteralPath $vdpPluginPath -Raw -Encoding UTF8) 'vdpPlugin.js'

$loginSelector = Get-Content -LiteralPath $loginSelectorPath -Raw -Encoding UTF8
$menuReplacement = @"
const menu = document.querySelector('.login-page-language-selector__menu');
        if (menu && !menu.querySelector('[data-veeam-zh-native="true"]')) {
            const templateItem = menu.querySelector('.login-page-language-selector__menu-item');
            if (templateItem) {
                const zhItem = templateItem.cloneNode(true);
                zhItem.dataset.veeamZhNative = 'true';
                zhItem.classList.remove('login-page-language-selector__menu-item--selected');
                zhItem.setAttribute('aria-selected', 'false');
                zhItem.querySelector('.login-page-language-selector__menu-item-text').textContent = '\u7b80\u4f53\u4e2d\u6587';
                zhItem.querySelector('input[name="Input.LanguageCode"]').value = 'zh-CN';
                menu.appendChild(zhItem);
            }
        }
        const menuItems = document.querySelectorAll('.login-page-language-selector__menu-item');
"@
$selectReplacement = @"
if (localeCode === 'zh-CN') {
                localStorage.setItem('$localeKey', localeCode);
                localStorage.setItem('localization:language', JSON.stringify(localeCode));
                if (!isInitialization) {
                    window.location.assign('/');
                }
                return;
            }
            localStorage.removeItem('$localeKey');
            localStorage.setItem('localization:language', JSON.stringify(localeCode));

            if (isInitialization)
                return;

            // Submit the form to proceed with the changes on the server side
"@
if (-not $loginSelector.Contains('data-veeam-zh-native')) {
    $menuPattern = "const menu = document\.querySelector\('\.login-page-language-selector__menu'\);\s*const menuItems = document\.querySelectorAll\('\.login-page-language-selector__menu-item'\);"
    $loginSelector = Replace-OnceRegex $loginSelector $menuPattern $menuReplacement 'login language menu'
} else {
    $zhTextPattern = New-Object -TypeName System.Text.RegularExpressions.Regex -ArgumentList "zhItem\.querySelector\('\.login-page-language-selector__menu-item-text'\)\.textContent = '[^']*';"
    $loginSelector = $zhTextPattern.Replace($loginSelector, "zhItem.querySelector('.login-page-language-selector__menu-item-text').textContent = '\u7b80\u4f53\u4e2d\u6587';", 1)
}
if (-not $loginSelector.Contains("localeCode === 'zh-CN'")) {
    $selectPattern = "if \(isInitialization\)\s*return;\s*// Submit the form to proceed with the changes on the server side"
    $loginSelector = Replace-OnceRegex $loginSelector $selectPattern $selectReplacement 'login language handling'
}

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
Copy-Item -LiteralPath $htmlPath -Destination $backupHtmlPath -Force
Copy-Item -LiteralPath $indexPath -Destination $backupIndexPath -Force
Copy-Item -LiteralPath $pluginPath -Destination $backupPluginPath -Force
Copy-Item -LiteralPath $vdpPluginPath -Destination $backupVdpPluginPath -Force
Copy-Item -LiteralPath $loginSelectorPath -Destination $backupLoginSelectorPath -Force
Copy-Item -LiteralPath $sourceNativeAssetPath -Destination $nativeAssetPath -Force
Copy-Item -LiteralPath $sourceCatalogAssetPath -Destination $catalogAssetPath -Force

$tempHtml = "$htmlPath.veeam-zh-cn-new"
$tempIndex = "$indexPath.veeam-zh-cn-new"
$tempPlugin = "$pluginPath.veeam-zh-cn-new"
$tempVdpPlugin = "$vdpPluginPath.veeam-zh-cn-new"
$tempLoginSelector = "$loginSelectorPath.veeam-zh-cn-new"
Write-Utf8NoBom $tempHtml ($html.Replace($moduleTag, $catalogTag + [Environment]::NewLine + '  ' + $nativeTag + [Environment]::NewLine + '  ' + $patchedModuleTag))
Write-Utf8NoBom $tempIndex $index
Write-Utf8NoBom $tempPlugin $plugin
Write-Utf8NoBom $tempVdpPlugin $vdpPlugin
Write-Utf8NoBom $tempLoginSelector $loginSelector
Move-Item -LiteralPath $tempHtml -Destination $htmlPath -Force
Move-Item -LiteralPath $tempIndex -Destination $indexPath -Force
Move-Item -LiteralPath $tempPlugin -Destination $pluginPath -Force
Move-Item -LiteralPath $tempVdpPlugin -Destination $vdpPluginPath -Force
Move-Item -LiteralPath $tempLoginSelector -Destination $loginSelectorPath -Force

$manifest = [ordered]@{
    Build = $build
    InstalledAt = (Get-Date).ToString('o')
    OriginalHtmlSha256 = $expectedHtmlHash
    OriginalIndexSha256 = $expectedIndexHash
    OriginalPluginSha256 = $pluginHash
    OriginalVdpPluginSha256 = $vdpPluginHash
    OriginalLoginSelectorSha256 = $loginSelectorHash
    PatchedHtmlSha256 = Get-Sha256 $htmlPath
    PatchedIndexSha256 = Get-Sha256 $indexPath
    PatchedPluginSha256 = Get-Sha256 $pluginPath
    PatchedVdpPluginSha256 = Get-Sha256 $vdpPluginPath
    PatchedLoginSelectorSha256 = Get-Sha256 $loginSelectorPath
    NativeAssetSha256 = Get-Sha256 $nativeAssetPath
    CatalogAssetSha256 = Get-Sha256 $catalogAssetPath
}
$manifest | ConvertTo-Json | Set-Content -LiteralPath $manifestPath -Encoding utf8

Write-Host 'Veeam Web UI Simplified Chinese package installed.' -ForegroundColor Green
Write-Host 'Hard-refresh the browser, then select Simplified Chinese from the language menu.'
