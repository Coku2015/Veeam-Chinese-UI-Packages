[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Assert-Administrator {
    $principal = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script from an elevated PowerShell session.'
    }
}

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-TextSha256([string]$Text) {
    $encoding = New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false
    $bytes = $encoding.GetBytes($Text)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        ([System.BitConverter]::ToString($sha256.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha256.Dispose()
    }
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object -TypeName System.Text.UTF8Encoding -ArgumentList $false))
}

function Replace-Required([string]$Text, [string]$Needle, [string]$Replacement, [string]$Name) {
    $count = ([regex]::Matches($Text, [regex]::Escape($Needle))).Count
    if ($count -ne 1) {
        throw "Expected $Name fragment exactly once, found $count. No files were changed."
    }
    $Text.Replace($Needle, $Replacement)
}

function Restart-VeeamOneReporterService {
    $service = Get-Service -Name 'VeeamRSS' -ErrorAction Stop
    if ($service.Status -ne [System.ServiceProcess.ServiceControllerStatus]::Running) {
        Write-Warning "Veeam ONE Reporting Service is not running ($($service.Status)). Start VeeamRSS manually before testing the UI."
        return
    }
    try {
        Restart-Service -Name 'VeeamRSS' -Force -ErrorAction Stop
        $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(60))
        Write-Host 'Restarted Veeam ONE Reporting Service (VeeamRSS).'
    }
    catch {
        Write-Warning 'Veeam ONE Reporting Service restart failed. Restart VeeamRSS manually before testing the UI.'
    }
}

Assert-Administrator

$build = '13.1.0.7034'
$packageSchema = 3
$expectedHtmlSha256 = 'c60b9653ad1f9273f53347570f7e7172e35579b74f1da36010d59577207f8304'
$expectedMainSha256 = 'abdbc07ad231bbce464b734213e0e515121bc3bf80959a25301b49959199ce39'
$expectedPluginSha256 = 'a7a8f439cade361c2704362a3babd04c27e38200996253dcc3ec9bba27488939'
$localeKey = 'veeamOneWebUiZhCNLocale'

$programFiles = $env:ProgramFiles
$programData = $env:ProgramData
$assetRoot = Join-Path $programFiles 'Veeam\Veeam ONE\Veeam ONE Reporter Server\Assets'
$htmlPath = Join-Path $assetRoot 'index.html'
$staticJsRoot = Join-Path $assetRoot 'static\js'
$mainPath = Join-Path $staticJsRoot 'main.1c26fdf6.js'
$pluginPath = Join-Path $assetRoot 'plugin\plugin.js'
$sourceCatalogAssetPath = Join-Path $PSScriptRoot 'assets\veeam-one-zh-CN-catalog.js'
$sourcePluginCatalogAssetPath = Join-Path $PSScriptRoot 'assets\veeam-one-zh-CN-plugin-catalog.js'

$backupRoot = Join-Path $programData "VeeamWebUiZhCN\VeeamONE-$build"
$backupHtmlPath = Join-Path $backupRoot 'index.html.original'
$backupPluginPath = Join-Path $backupRoot 'plugin.js.original'
$manifestPath = Join-Path $backupRoot 'manifest.json'

$moduleTag = '<script defer="defer" src="/static/js/main.1c26fdf6.js"></script>'
$oldStorage = 'const i={getValue:()=>null,setValue:()=>{},clear:()=>{}};'
$newStorage = 'const i={getValue:()=>localStorage.getItem("' + $localeKey + '"),setValue:e=>{e==="zh-CN"?localStorage.setItem("' + $localeKey + '",e):localStorage.removeItem("' + $localeKey + '")},clear:()=>{localStorage.removeItem("' + $localeKey + '")}};'
$registryStart = 'uj=[dy,'
$registryTail = ',Ll,GD]'
$zhLocale = ',{iso:"zh-CN",title:"\u7b80\u4f53\u4e2d\u6587",flag:"",resources:globalThis.__VeeamOneZhCatalog}'

foreach ($path in @($htmlPath, $mainPath, $pluginPath, $sourceCatalogAssetPath, $sourcePluginCatalogAssetPath)) {
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Required Veeam ONE Web UI file was not found: $path"
    }
}

$sourceCatalogSha256 = Get-Sha256 $sourceCatalogAssetPath
if (Test-Path -LiteralPath $manifestPath) {
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.PackageSchema -ne $packageSchema) {
        throw 'A previous Veeam ONE Chinese package installation was found. Run this package uninstall script first. No files were changed.'
    }
    $installedCatalogPath = Join-Path $staticJsRoot $manifest.GeneratedCatalogFileName
    $installedMainPath = Join-Path $staticJsRoot $manifest.GeneratedMainFileName
    if ((Get-Sha256 $htmlPath) -eq $manifest.PatchedHtmlSha256 -and
        (Test-Path -LiteralPath $installedCatalogPath) -and
        (Get-Sha256 $installedCatalogPath) -eq $manifest.GeneratedCatalogSha256 -and
        (Test-Path -LiteralPath $installedMainPath) -and
        (Get-Sha256 $installedMainPath) -eq $manifest.GeneratedMainSha256 -and
        (Get-Sha256 $pluginPath) -eq $manifest.PatchedPluginSha256) {
        Write-Host 'Veeam ONE Simplified Chinese package is already installed. No changes were made.' -ForegroundColor Yellow
        exit 0
    }
    throw 'An existing Veeam ONE package manifest was found, but current files do not match it. Uninstall it first. No files were changed.'
}
if (Test-Path -LiteralPath $backupRoot) {
    throw 'A package backup directory exists without a manifest. Inspect or restore it before installing. No files were changed.'
}

$htmlHash = Get-Sha256 $htmlPath
$mainHash = Get-Sha256 $mainPath
$pluginHash = Get-Sha256 $pluginPath
if ($htmlHash -ne $expectedHtmlSha256 -or $mainHash -ne $expectedMainSha256 -or $pluginHash -ne $expectedPluginSha256) {
    throw "Current Veeam ONE Web UI hashes do not match build $build. The server may have been upgraded or modified. No files were changed."
}

$html = Get-Content -LiteralPath $htmlPath -Raw -Encoding UTF8
$main = Get-Content -LiteralPath $mainPath -Raw -Encoding UTF8
$pluginOriginal = Get-Content -LiteralPath $pluginPath -Raw -Encoding UTF8
if ($html.Contains('veeam-one-zh-CN-catalog')) {
    throw 'A Veeam ONE Chinese catalog script is already present without a package manifest. No files were changed.'
}

$patchedMain = Replace-Required $main $oldStorage $newStorage 'language storage'
$registryStartPosition = $patchedMain.IndexOf($registryStart, [System.StringComparison]::Ordinal)
if ($registryStartPosition -lt 0) {
    throw 'The Veeam ONE language registry was not found. No files were changed.'
}
$registryTailPosition = $patchedMain.IndexOf($registryTail, $registryStartPosition, [System.StringComparison]::Ordinal)
if ($registryTailPosition -lt 0 -or $patchedMain.IndexOf($registryTail, $registryTailPosition + $registryTail.Length, [System.StringComparison]::Ordinal) -ge 0) {
    throw 'The Veeam ONE language registry boundary is unexpected. No files were changed.'
}
$patchedMain = $patchedMain.Insert($registryTailPosition, $zhLocale)

$pluginCatalog = Get-Content -LiteralPath $sourcePluginCatalogAssetPath -Raw -Encoding UTF8
if (-not $pluginCatalog.Contains('globalThis.__VeeamOnePluginZhCatalog =')) {
    throw 'The Veeam ONE plugin Chinese catalog asset is invalid. No files were changed.'
}
$pluginRegistryNeedle = 'var RJo=[dNt,dYt,BMt,BWt],BL=RJo;'
$pluginRegistryReplacement = 'var RJo=[dNt,dYt,BMt,BWt,{iso:"zh-CN",title:"\u7b80\u4f53\u4e2d\u6587",flag:"",resources:globalThis.__VeeamOnePluginZhCatalog}],BL=RJo;'
$patchedPluginCore = Replace-Required $pluginOriginal $pluginRegistryNeedle $pluginRegistryReplacement 'Veeam ONE plugin language registry'
$patchedPlugin = $pluginCatalog.TrimEnd() + [Environment]::NewLine + $patchedPluginCore

$generatedCatalogFileName = 'veeam-one-zh-CN-catalog.' + $sourceCatalogSha256.Substring(0, 16) + '.js'
$generatedMainSha256 = Get-TextSha256 $patchedMain
$generatedMainFileName = 'main.1c26fdf6.zh-CN.' + $generatedMainSha256.Substring(0, 16) + '.js'
$generatedCatalogPath = Join-Path $staticJsRoot $generatedCatalogFileName
$generatedMainPath = Join-Path $staticJsRoot $generatedMainFileName
$catalogTag = '<script defer="defer" src="/static/js/' + $generatedCatalogFileName + '"></script>'
$patchedModuleTag = '<script defer="defer" src="/static/js/' + $generatedMainFileName + '"></script>'
$patchedHtml = Replace-Required $html $moduleTag ($catalogTag + [Environment]::NewLine + $patchedModuleTag) 'main HTML script tag'

foreach ($path in @($generatedCatalogPath, $generatedMainPath)) {
    if (Test-Path -LiteralPath $path) {
        throw "A file using this package fingerprint already exists: $path. No files were changed."
    }
}

$tempHtml = "$htmlPath.veeam-zh-cn-new"
$tempCatalog = "$generatedCatalogPath.veeam-zh-cn-new"
$tempMain = "$generatedMainPath.veeam-zh-cn-new"
$tempPlugin = "$pluginPath.veeam-zh-cn-new"
$tempManifest = "$manifestPath.veeam-zh-cn-new"
$catalogInstalled = $false
$mainInstalled = $false
$pluginInstalled = $false
$manifestWritten = $false

New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
Copy-Item -LiteralPath $htmlPath -Destination $backupHtmlPath -Force
Copy-Item -LiteralPath $pluginPath -Destination $backupPluginPath -Force

try {
    Copy-Item -LiteralPath $sourceCatalogAssetPath -Destination $tempCatalog -Force
    Write-Utf8NoBom $tempMain $patchedMain
    Write-Utf8NoBom $tempPlugin $patchedPlugin
    Write-Utf8NoBom $tempHtml $patchedHtml
    Move-Item -LiteralPath $tempCatalog -Destination $generatedCatalogPath -Force
    $catalogInstalled = $true
    Move-Item -LiteralPath $tempMain -Destination $generatedMainPath -Force
    $mainInstalled = $true
    Move-Item -LiteralPath $tempPlugin -Destination $pluginPath -Force
    $pluginInstalled = $true
    Move-Item -LiteralPath $tempHtml -Destination $htmlPath -Force

    $manifest = [ordered]@{
        PackageSchema = $packageSchema
        Product = 'Veeam ONE Web UI'
        Build = $build
        InstalledAt = (Get-Date).ToString('o')
        OriginalHtmlSha256 = $htmlHash
        OriginalMainSha256 = $mainHash
        PatchedHtmlSha256 = Get-Sha256 $htmlPath
        GeneratedCatalogFileName = $generatedCatalogFileName
        GeneratedCatalogSha256 = Get-Sha256 $generatedCatalogPath
        GeneratedMainFileName = $generatedMainFileName
        GeneratedMainSha256 = Get-Sha256 $generatedMainPath
        OriginalPluginSha256 = $pluginHash
        PatchedPluginSha256 = Get-Sha256 $pluginPath
    }
    $manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $tempManifest -Encoding UTF8
    Move-Item -LiteralPath $tempManifest -Destination $manifestPath -Force
    $manifestWritten = $true
}
catch {
    if (Test-Path -LiteralPath $tempHtml) { Remove-Item -LiteralPath $tempHtml -Force }
    if (Test-Path -LiteralPath $tempCatalog) { Remove-Item -LiteralPath $tempCatalog -Force }
    if (Test-Path -LiteralPath $tempMain) { Remove-Item -LiteralPath $tempMain -Force }
    if (Test-Path -LiteralPath $tempPlugin) { Remove-Item -LiteralPath $tempPlugin -Force }
    if (Test-Path -LiteralPath $tempManifest) { Remove-Item -LiteralPath $tempManifest -Force }
    try {
        if (Test-Path -LiteralPath $backupHtmlPath) {
            Copy-Item -LiteralPath $backupHtmlPath -Destination "$htmlPath.veeam-zh-cn-rollback" -Force
            Move-Item -LiteralPath "$htmlPath.veeam-zh-cn-rollback" -Destination $htmlPath -Force
        }
        if ($mainInstalled -and (Test-Path -LiteralPath $generatedMainPath) -and ((Get-Sha256 $generatedMainPath) -eq $generatedMainSha256)) {
            Remove-Item -LiteralPath $generatedMainPath -Force
        }
        if ($pluginInstalled -and (Test-Path -LiteralPath $backupPluginPath)) {
            Copy-Item -LiteralPath $backupPluginPath -Destination "$pluginPath.veeam-zh-cn-rollback" -Force
            Move-Item -LiteralPath "$pluginPath.veeam-zh-cn-rollback" -Destination $pluginPath -Force
        }
        if ($catalogInstalled -and (Test-Path -LiteralPath $generatedCatalogPath) -and ((Get-Sha256 $generatedCatalogPath) -eq $sourceCatalogSha256)) {
            Remove-Item -LiteralPath $generatedCatalogPath -Force
        }
        if ($manifestWritten -and (Test-Path -LiteralPath $manifestPath)) {
            Remove-Item -LiteralPath $manifestPath -Force
        }
    }
    catch {
        Write-Warning 'Automatic rollback did not complete. Keep the backup directory and restore the original HTML file manually.'
    }
    throw
}

Restart-VeeamOneReporterService
Write-Host 'Veeam ONE Simplified Chinese package installed.' -ForegroundColor Green
Write-Host 'The package uses fingerprinted main assets and embeds the reviewed Chinese catalog in the Veeam ONE plugin bundle.'
Write-Host 'Reload the UI, then select zh-CN (Simplified Chinese) from the language menu.'
