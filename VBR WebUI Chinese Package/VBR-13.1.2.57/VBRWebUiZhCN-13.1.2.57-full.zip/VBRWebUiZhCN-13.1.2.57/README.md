# Veeam Backup & Replication Web UI 简体中文补丁包

适用版本：Veeam Backup & Replication Web UI `13.1.2.57`

此包基于 `review/veeam-webui-13.1.2.57-zh-CN-review.po` 生成：

- catalog 条目：10358（主 Web UI 10009 条，AHV/PVE 扩展 349 条）
- 已审核中文译文：10342
- 源文为空、无需翻译：16
- 有英文源文但未翻译：0
- fallback English：0
- PO fuzzy：0
- AHV/PVE Restore 向导扩展资源：349 条（AHV 165 条、PVE 184 条）

## 设计说明

此补丁包会在 Veeam Web UI 中增加第五种语言：`简体中文`。原有 English、German、French、Japanese 不会被覆盖。

安装器只修改 Web UI 前端静态文件：

- `index.html`
- `assets/index-BKG9pzd8.js`
- `plugin/plugin.js`
- `plugin/vdpPlugin.js`
- Linux Appliance 扩展插件：
  - `/opt/veeam/backup/plugins/ahv/service/wwwroot/plugin/plugin.js`
  - `/opt/veeam/backup/plugins/pve/service/wwwroot/plugin/plugin.js`
- OAuth 登录页 `wwwroot/oauth/static/lib/languageSelector.js`
- 新增 `assets/veeam-zh-CN-catalog.js`
- 新增 `assets/veeam-zh-CN-native.js`

分析页面会在每次打开仪表板、报表或告警概览时重新读取 `veeamWebUiZhNativeLocale`。这样在 English、日文、德文、法文和简体中文之间反复切换后，VBR 传给远程 Veeam ONE 插件的语言仍会与当前选择一致，不会因 VBR 内部回退到 English 而把分析页面锁定为英文。若用户在分析页面内直接从其他语言切换到中文，原生语言层会检测到状态变化并执行一次受保护的 SPA 刷新，避免复用旧的英文分析组件。新版 HTML 还会给本地脚本、主 bundle 和远程 Veeam ONE 插件 URL 添加缓存指纹，避免浏览器或反向代理继续提供旧资源。

安装前会备份原始文件，卸载时会校验当前文件确实由本补丁写入，然后再还原。这样可以避免误覆盖 Veeam 升级后的文件。

建议在升级 Veeam 前先卸载此补丁；升级完成后，如 Web UI build 仍匹配，再重新安装对应版本补丁。

## Windows 安装

在 Veeam Backup Server 上，以管理员身份打开 PowerShell：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
    cd C:\Users\Administrator\Downloads\VBRWebUiZhCN-13.1.2.57\windows
.\Install-VBRWebUiZhCN.ps1
```

安装后浏览器按 `Ctrl+F5` 强制刷新，然后在语言菜单选择“简体中文”。

如果之前安装过旧 preview 或旧版测试包，请先运行对应卸载脚本还原，再安装此包。新版卸载脚本兼容旧版 Linux manifest，可用于先还原旧 Linux 包。

## Windows 卸载还原

以管理员身份打开 PowerShell：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
    cd C:\Users\Administrator\Downloads\VBRWebUiZhCN-13.1.2.57\windows
.\Uninstall-VBRWebUiZhCN.ps1
```

备份目录：`C:\ProgramData\VeeamWebUiZhCN\13.1.2.57`

## Linux Appliance 安装

解压后，在 Linux backup server 上执行：

```bash
cd /path/to/VBRWebUiZhCN-13.1.2.57/linux
bash ./install-veeam-webui-zh-cn.sh
```

默认 Web UI 路径：`/opt/veeam/vbr/BackupWebUI`

如果你的 Linux Appliance 路径不同，可以显式指定：

```bash
cd /path/to/VBRWebUiZhCN-13.1.2.57/linux
env WEB_ROOT=/opt/veeam/vbr/BackupWebUI bash ./install-veeam-webui-zh-cn.sh
```

如果 appliance 的原始文件 hash 与 Windows build 不同，但你确认页面片段兼容，可以显式允许非 hash 校验安装：

```bash
env ALLOW_UNVERIFIED=1 WEB_ROOT=/opt/veeam/vbr/BackupWebUI bash ./install-veeam-webui-zh-cn.sh
```

默认情况下脚本会保守拒绝 hash 不匹配的文件，避免影响升级后的服务器。

此版本额外补入 AHV/PVE Restore 向导的原生 zh-CN 资源，用于修复 Instant Recovery / Entire VM Restore 中步骤说明、弹窗、侧滑面板、表格列名仍显示英文的问题。

## Linux Appliance 卸载还原

```bash
cd /path/to/VBRWebUiZhCN-13.1.2.57/linux
bash ./uninstall-veeam-webui-zh-cn.sh
```

备份目录：`/var/lib/veeam-webui-zh-cn/13.1.2.57`

## 注意事项

- 这是非官方 Web UI 本地化补丁包，不是 Veeam 官方 hotfix。
- 不修改 Veeam updater，不伪装官方补丁格式。
- 如安装器提示 hash 不匹配，应先确认 Veeam 版本、是否已安装旧 preview、是否已升级。
- 如果之前安装过旧版 native/catalog preview，请先用旧版卸载脚本恢复原始文件，再安装此正式包。
