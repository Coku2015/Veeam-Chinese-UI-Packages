#!/usr/bin/env bash
set -euo pipefail

BUILD="13.1.0.411"
EXPECTED_HTML_SHA256="76dc7dbf81e9e42720d1842cd556d5e880d29f09ab8ba3235caef31553dc1513"
EXPECTED_INDEX_SHA256="bcaa9af5c11f9818009b893a9b6da39f1d1be3efe05bb94bb48ad9cc05a893c4"
EXPECTED_PLUGIN_SHA256="d356026d5fa92cfc56e24fdb1d58e6959f4a16c09685ba5ea95272d8b60cdbce"
EXPECTED_VDP_PLUGIN_SHA256="aca08c17fe891429dd7b0b405264e939ed4af86bd15c2171c6028c7685769d35"
EXPECTED_AHV_PLUGIN_SHA256="4affaab5658c1a991920eb437b06c837d667aa26f77d2b112c2ac91499031735"
EXPECTED_PVE_PLUGIN_SHA256="88d0cb339d96f4cffc6155c977da0e6e46279c29b89d69580bc12da72772250d"
NATIVE_ONLY_HTML_SHA256="27e5ebb87ae0db70bb00c3fddac07285c48dc9b6f89f6a8cc7a332925cacd0ca"
NATIVE_ONLY_INDEX_SHA256="16088cd2afc8346b1229d2b278dcd95d0be3c32db51e25c1969b87d46fc6ef39"

die() {
  echo "ERROR: $*" >&2
  exit 1
}

sha256_file() {
  sha256sum "$1" | awk '{print tolower($1)}'
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"
}

if [[ "${EUID}" -ne 0 ]]; then
  die "Run this script as root: sudo ./install-veeam-webui-zh-cn.sh"
fi

require_command sha256sum
require_command awk
require_command python3

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "${WEB_ROOT:-}" ]]; then
  for candidate in \
    "/opt/veeam/vbr/BackupWebUI" \
    "/opt/veeam/vbr/backupwebui" \
    "/opt/veeam/BackupWebUI"; do
    if [[ -f "${candidate}/index.html" && -d "${candidate}/assets" ]]; then
      WEB_ROOT="${candidate}"
      break
    fi
  done
fi

WEB_ROOT="${WEB_ROOT:-/opt/veeam/vbr/BackupWebUI}"
HTML_PATH="${WEB_ROOT}/index.html"
ASSETS_DIR="${WEB_ROOT}/assets"
INDEX_PATH="${ASSETS_DIR}/index-BJPSD5I9.js"
PLUGIN_PATH="${WEB_ROOT}/plugin/plugin.js"
VDP_PLUGIN_PATH="${WEB_ROOT}/plugin/vdpPlugin.js"
AHV_PLUGIN_PATH="${AHV_PLUGIN_PATH:-/opt/veeam/backup/plugins/ahv/service/wwwroot/plugin/plugin.js}"
PVE_PLUGIN_PATH="${PVE_PLUGIN_PATH:-/opt/veeam/backup/plugins/pve/service/wwwroot/plugin/plugin.js}"
NATIVE_ASSET_PATH="${ASSETS_DIR}/veeam-zh-CN-native.js"
CATALOG_ASSET_PATH="${ASSETS_DIR}/veeam-zh-CN-catalog.js"
SOURCE_NATIVE_ASSET_PATH="${SCRIPT_DIR}/assets/veeam-zh-CN-native.js"
SOURCE_CATALOG_ASSET_PATH="${SCRIPT_DIR}/assets/veeam-zh-CN-catalog.js"

if [[ -z "${LOGIN_SELECTOR_PATH:-}" ]]; then
  WEB_PARENT="$(cd -- "${WEB_ROOT}/.." && pwd)"
  for candidate in \
    "${WEB_PARENT}/Backup/wwwroot/oauth/static/lib/languageSelector.js" \
    "${WEB_PARENT}/backup/wwwroot/oauth/static/lib/languageSelector.js" \
    "/opt/veeam/vbr/Backup/wwwroot/oauth/static/lib/languageSelector.js" \
    "/opt/veeam/vbr/backup/wwwroot/oauth/static/lib/languageSelector.js"; do
    if [[ -f "${candidate}" ]]; then
      LOGIN_SELECTOR_PATH="${candidate}"
      break
    fi
  done
fi

if [[ -z "${LOGIN_SELECTOR_PATH:-}" && -d /opt/veeam ]]; then
  LOGIN_SELECTOR_PATH="$(find /opt/veeam -path '*/oauth/static/lib/languageSelector.js' -type f -print -quit 2>/dev/null || true)"
fi

BACKUP_ROOT="/var/lib/veeam-webui-zh-cn/${BUILD}"
BACKUP_HTML_PATH="${BACKUP_ROOT}/index.html.original"
BACKUP_INDEX_PATH="${BACKUP_ROOT}/index-BJPSD5I9.js.original"
BACKUP_PLUGIN_PATH="${BACKUP_ROOT}/plugin.js.original"
BACKUP_VDP_PLUGIN_PATH="${BACKUP_ROOT}/vdpPlugin.js.original"
BACKUP_AHV_PLUGIN_PATH="${BACKUP_ROOT}/ahv-plugin.js.original"
BACKUP_PVE_PLUGIN_PATH="${BACKUP_ROOT}/pve-plugin.js.original"
BACKUP_LOGIN_SELECTOR_PATH="${BACKUP_ROOT}/languageSelector.js.original"
MANIFEST_PATH="${BACKUP_ROOT}/manifest.env"

[[ -f "${HTML_PATH}" ]] || die "index.html was not found: ${HTML_PATH}"
[[ -f "${INDEX_PATH}" ]] || die "Main Web UI bundle was not found: ${INDEX_PATH}"
[[ -f "${PLUGIN_PATH}" ]] || die "Web UI plugin bundle was not found: ${PLUGIN_PATH}"
[[ -f "${VDP_PLUGIN_PATH}" ]] || die "Web UI VDP plugin bundle was not found: ${VDP_PLUGIN_PATH}"
[[ -f "${AHV_PLUGIN_PATH}" ]] || die "AHV extension plugin bundle was not found: ${AHV_PLUGIN_PATH}"
[[ -f "${PVE_PLUGIN_PATH}" ]] || die "PVE extension plugin bundle was not found: ${PVE_PLUGIN_PATH}"
[[ -f "${LOGIN_SELECTOR_PATH:-}" ]] || die "OAuth login language selector was not found. Set LOGIN_SELECTOR_PATH=/path/to/languageSelector.js and retry."
[[ -f "${SOURCE_NATIVE_ASSET_PATH}" ]] || die "Package asset is missing: ${SOURCE_NATIVE_ASSET_PATH}"
[[ -f "${SOURCE_CATALOG_ASSET_PATH}" ]] || die "Package asset is missing: ${SOURCE_CATALOG_ASSET_PATH}"

HTML_SHA256="$(sha256_file "${HTML_PATH}")"
INDEX_SHA256="$(sha256_file "${INDEX_PATH}")"
PLUGIN_SHA256="$(sha256_file "${PLUGIN_PATH}")"
VDP_PLUGIN_SHA256="$(sha256_file "${VDP_PLUGIN_PATH}")"
AHV_PLUGIN_SHA256="$(sha256_file "${AHV_PLUGIN_PATH}")"
PVE_PLUGIN_SHA256="$(sha256_file "${PVE_PLUGIN_PATH}")"
LOGIN_SELECTOR_SHA256="$(sha256_file "${LOGIN_SELECTOR_PATH}")"
SOURCE_NATIVE_SHA256="$(sha256_file "${SOURCE_NATIVE_ASSET_PATH}")"
SOURCE_CATALOG_SHA256="$(sha256_file "${SOURCE_CATALOG_ASSET_PATH}")"

if [[ -f "${MANIFEST_PATH}" ]]; then
  # shellcheck disable=SC1090
  source "${MANIFEST_PATH}"
  if [[ -z "${PATCHED_LOGIN_SELECTOR_SHA256:-}" ]]; then
    die "An older package manifest was found. Run ./uninstall-veeam-webui-zh-cn.sh from this package first, then run the installer again."
  fi
  if [[ -z "${PATCHED_PLUGIN_SHA256:-}" || -z "${PATCHED_VDP_PLUGIN_SHA256:-}" ||
        -z "${PATCHED_AHV_PLUGIN_SHA256:-}" || -z "${PATCHED_PVE_PLUGIN_SHA256:-}" ]]; then
    die "An older package manifest was found. Uninstall the old package first, then install this package."
  fi
  ASSETS_MATCH="no"
  if [[ -f "${NATIVE_ASSET_PATH}" && -f "${CATALOG_ASSET_PATH}" ]] &&
     [[ "$(sha256_file "${NATIVE_ASSET_PATH}")" == "${NATIVE_ASSET_SHA256}" ]] &&
     [[ "$(sha256_file "${CATALOG_ASSET_PATH}")" == "${CATALOG_ASSET_SHA256}" ]]; then
    ASSETS_MATCH="yes"
  fi
  if [[ "${HTML_SHA256}" == "${PATCHED_HTML_SHA256}" &&
        "${INDEX_SHA256}" == "${PATCHED_INDEX_SHA256}" &&
        "${PLUGIN_SHA256}" == "${PATCHED_PLUGIN_SHA256}" &&
        "${VDP_PLUGIN_SHA256}" == "${PATCHED_VDP_PLUGIN_SHA256}" &&
        "${AHV_PLUGIN_SHA256}" == "${PATCHED_AHV_PLUGIN_SHA256}" &&
        "${PVE_PLUGIN_SHA256}" == "${PATCHED_PVE_PLUGIN_SHA256}" &&
        "$(sha256_file "${LOGIN_SELECTOR_PATH}")" == "${PATCHED_LOGIN_SELECTOR_SHA256}" &&
        "${ASSETS_MATCH}" == "yes" ]]; then
    echo "Veeam Web UI Simplified Chinese package is already installed. No changes were made."
    exit 0
  fi
  die "An existing manifest was found, but current Web UI files do not match it. No changes were made."
fi

if [[ "${HTML_SHA256}" == "${NATIVE_ONLY_HTML_SHA256}" &&
      "${INDEX_SHA256}" == "${NATIVE_ONLY_INDEX_SHA256}" ]]; then
  die "An older native preview appears to be installed. Uninstall the old preview first, then install this package."
fi

if [[ "${HTML_SHA256}" != "${EXPECTED_HTML_SHA256}" ||
      "${INDEX_SHA256}" != "${EXPECTED_INDEX_SHA256}" ||
      "${PLUGIN_SHA256}" != "${EXPECTED_PLUGIN_SHA256}" ||
      "${VDP_PLUGIN_SHA256}" != "${EXPECTED_VDP_PLUGIN_SHA256}" ||
      "${AHV_PLUGIN_SHA256}" != "${EXPECTED_AHV_PLUGIN_SHA256}" ||
      "${PVE_PLUGIN_SHA256}" != "${EXPECTED_PVE_PLUGIN_SHA256}" ]]; then
  if [[ "${ALLOW_UNVERIFIED:-0}" != "1" ]]; then
    die "Current Web UI hashes do not match VBR ${BUILD}. The server may have been upgraded, patched, or may use different appliance files. No changes were made. If you have verified compatibility, run: sudo env ALLOW_UNVERIFIED=1 ./install-veeam-webui-zh-cn.sh"
  fi
  echo "WARNING: ALLOW_UNVERIFIED=1 is set. Continuing only if required code fragments are found." >&2
fi

if [[ -f "${NATIVE_ASSET_PATH}" && "$(sha256_file "${NATIVE_ASSET_PATH}")" != "${SOURCE_NATIVE_SHA256}" ]]; then
  die "A different native Chinese asset already exists: ${NATIVE_ASSET_PATH}"
fi
if [[ -f "${CATALOG_ASSET_PATH}" && "$(sha256_file "${CATALOG_ASSET_PATH}")" != "${SOURCE_CATALOG_SHA256}" ]]; then
  die "A different Chinese catalog asset already exists: ${CATALOG_ASSET_PATH}"
fi

mkdir -p "${BACKUP_ROOT}"
cp -p "${HTML_PATH}" "${BACKUP_HTML_PATH}"
cp -p "${INDEX_PATH}" "${BACKUP_INDEX_PATH}"
cp -p "${PLUGIN_PATH}" "${BACKUP_PLUGIN_PATH}"
cp -p "${VDP_PLUGIN_PATH}" "${BACKUP_VDP_PLUGIN_PATH}"
cp -p "${AHV_PLUGIN_PATH}" "${BACKUP_AHV_PLUGIN_PATH}"
cp -p "${PVE_PLUGIN_PATH}" "${BACKUP_PVE_PLUGIN_PATH}"
cp -p "${LOGIN_SELECTOR_PATH}" "${BACKUP_LOGIN_SELECTOR_PATH}"

TMP_HTML="${HTML_PATH}.veeam-zh-cn-new.$$"
TMP_INDEX="${INDEX_PATH}.veeam-zh-cn-new.$$"
TMP_PLUGIN="${PLUGIN_PATH}.veeam-zh-cn-new.$$"
TMP_VDP_PLUGIN="${VDP_PLUGIN_PATH}.veeam-zh-cn-new.$$"
TMP_AHV_PLUGIN="${AHV_PLUGIN_PATH}.veeam-zh-cn-new.$$"
TMP_PVE_PLUGIN="${PVE_PLUGIN_PATH}.veeam-zh-cn-new.$$"
TMP_LOGIN_SELECTOR="${LOGIN_SELECTOR_PATH}.veeam-zh-cn-new.$$"
cleanup() {
  rm -f "${TMP_HTML}" "${TMP_INDEX}" "${TMP_PLUGIN}" "${TMP_VDP_PLUGIN}" "${TMP_AHV_PLUGIN}" "${TMP_PVE_PLUGIN}" "${TMP_LOGIN_SELECTOR}"
}
trap cleanup EXIT

python3 - "${HTML_PATH}" "${INDEX_PATH}" "${PLUGIN_PATH}" "${VDP_PLUGIN_PATH}" "${AHV_PLUGIN_PATH}" "${PVE_PLUGIN_PATH}" "${LOGIN_SELECTOR_PATH}" "${TMP_HTML}" "${TMP_INDEX}" "${TMP_PLUGIN}" "${TMP_VDP_PLUGIN}" "${TMP_AHV_PLUGIN}" "${TMP_PVE_PLUGIN}" "${TMP_LOGIN_SELECTOR}" <<'PY'
import re
import sys
from pathlib import Path

html_path, index_path, plugin_path, vdp_plugin_path, ahv_plugin_path, pve_plugin_path, login_selector_path, tmp_html, tmp_index, tmp_plugin, tmp_vdp_plugin, tmp_ahv_plugin, tmp_pve_plugin, tmp_login_selector = map(Path, sys.argv[1:])

module_tag = '<script type="module" crossorigin src="./assets/index-BJPSD5I9.js"></script>'
catalog_tag = '<script src="./assets/veeam-zh-CN-catalog.js?v=99f6742c826c3e0b"></script>'
native_tag = '<script src="./assets/veeam-zh-CN-native.js?v=b623b0ca2adff0b4"></script>'
patched_module_tag = '<script type="module" crossorigin src="./assets/index-BJPSD5I9.js?v=veeam-zh-cn-analytics-r3"></script>'

html = html_path.read_text(encoding='utf-8')
if module_tag not in html:
    raise SystemExit('Expected Web UI module script tag was not found.')
if 'veeam-zh-CN-catalog.js' in html or 'veeam-zh-CN-native.js' in html:
    raise SystemExit('Chinese script tags already exist. Verify the current state or uninstall first.')

def jq(value: str) -> str:
    return '`' + value + '`'

def language(iso: str, title: str, resource: str) -> str:
    return '{iso:' + jq(iso) + ',title:' + jq(title) + ',flag:' + jq('') + ',resources:' + resource + '}'

en = language('en', 'English', 'qre')
ja = language('ja', '\u65e5\u672c\u8a9e', 'Gre')
de = language('de', 'Deutsch', 'Kre')
fr = language('fr', 'Français', 'uie')
zh = language('zh-CN', '\u7b80\u4f53\u4e2d\u6587', 'globalThis.__VeeamWebUiZhCatalog')

old_registry = 'im=[' + en + ',' + ja + ',' + de + ',' + fr + ']'
new_registry = 'im=[' + en + ',' + ja + ',' + de + ',' + fr + ',' + zh + ']'
locale_key = 'veeamWebUiZhNativeLocale'
q_key = jq(locale_key)
q_zh = jq('zh-CN')
q_en = jq('en')
q_plugin_key = jq('localization:language')
old_storage = 'Dfe=class{constructor(e){this.localizationService=e,this.getValue=()=>this.localizationService.language,this.setValue=e=>{},this.clear=()=>{}}}'
new_storage = 'Dfe=class{constructor(e){this.localizationService=e,this.getValue=()=>localStorage.getItem(' + q_key + ')??this.localizationService.language,this.setValue=e=>{e===' + q_zh + '?localStorage.setItem(' + q_key + ',e):localStorage.removeItem(' + q_key + ')},this.clear=()=>{localStorage.removeItem(' + q_key + ')}}}'
old_setter = 'Ofe=class e{static{this.create=t=>new e(t)}constructor(e){this.userSettingsStore=e,this.setLanguage=async({newLanguage:e,abortSignal:t})=>{await this.userSettingsStore.setLanguage({lang:e,abortSignal:t})}}get language(){return this.userSettingsStore.getValueOrDefault().lang}}'
new_setter = 'Ofe=class e{static{this.create=t=>new e(t)}constructor(e){this.userSettingsStore=e,this.setLanguage=async({newLanguage:e,abortSignal:t})=>{localStorage.setItem(' + q_plugin_key + ',JSON.stringify(e));if(e===' + q_zh + '){localStorage.setItem(' + q_key + ',e);await this.userSettingsStore.setLanguage({lang:' + q_en + ',abortSignal:t});globalThis.location?.reload?.();return;}localStorage.removeItem(' + q_key + ');await this.userSettingsStore.setLanguage({lang:e,abortSignal:t})}}get language(){return this.userSettingsStore.getValueOrDefault().lang}}'
old_analytics_presenter = 'lye=class{constructor(e,t){this.controller=e,this.localizationService=t}showDashboards(e,t){this.controller.renderDashboards(e,t,this.localizationService.language)}showReports(e,t){this.controller.renderReports(e,t,this.localizationService.language)}get isAlarmOverviewSupported(){return this.controller.version===ls.v2}showAlarmOverview(e,t){this.controller.version===ls.v2&&this.controller.renderAlarms(e,t,this.localizationService.language)}}'
new_analytics_presenter = 'lye=class{constructor(e,t){this.controller=e,this.localizationService=t,this.getLanguage=()=>localStorage.getItem(`veeamWebUiZhNativeLocale`)===`zh-CN`?`zh-CN`:this.localizationService.language}showDashboards(e,t){this.controller.renderDashboards(e,t,this.getLanguage())}showReports(e,t){this.controller.renderReports(e,t,this.getLanguage())}get isAlarmOverviewSupported(){return this.controller.version===ls.v2}showAlarmOverview(e,t){this.controller.version===ls.v2&&this.controller.renderAlarms(e,t,this.getLanguage())}}'
old_veeam_one_plugin_url = 'this.getUrlToBundle=e=>(e.endsWith(`/`)?e:e+`/`)+`plugin/plugin.js`'
new_veeam_one_plugin_url = 'this.getUrlToBundle=e=>(e.endsWith(`/`)?e:e+`/`)+`plugin/plugin.js?veeam-zh-cn-analytics-r3`'

index = index_path.read_text(encoding='utf-8')
for name, old in [('language registry', old_registry), ('language local storage', old_storage), ('language persistence', old_setter)]:
    if old not in index:
        raise SystemExit('Expected ' + name + ' fragment was not found.')
index = index.replace(old_registry, new_registry)
index = index.replace(old_storage, new_storage)
index = index.replace(old_setter, new_setter)
if old_analytics_presenter not in index:
    raise SystemExit('Expected Veeam ONE analytics language forwarding fragment was not found.')
index = index.replace(old_analytics_presenter, new_analytics_presenter, 1)
if old_veeam_one_plugin_url not in index:
    raise SystemExit('Expected Veeam ONE plugin cache-busting URL fragment was not found.')
index = index.replace(old_veeam_one_plugin_url, new_veeam_one_plugin_url, 1)

def patch_plugin_language_bundle(text: str, name: str) -> str:
    if 'iso:`zh-CN`,title:`简体中文`,flag:``,resources:globalThis.__VeeamWebUiZhCatalog' in text:
        raise SystemExit(name + ' already contains the Chinese plugin language entry.')
    marker = '=[{iso:`en`,title:`English`,flag:``,resources:{'
    marker_pos = text.find(marker)
    if marker_pos < 0:
        raise SystemExit('Expected plugin language registry fragment was not found in ' + name + '.')
    start = text.find('[', marker_pos)
    depth = 0
    quote = ''
    escaped = False
    end = -1
    for idx in range(start, len(text)):
        ch = text[idx]
        if quote:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == quote:
                quote = ''
            continue
        if ch in ('"', "'", '`'):
            quote = ch
        elif ch == '[':
            depth += 1
        elif ch == ']':
            depth -= 1
            if depth == 0:
                end = idx
                break
    if end < 0:
        raise SystemExit('Could not find the end of plugin language registry in ' + name + '.')
    zh_entry = ',{iso:`zh-CN`,title:`简体中文`,flag:``,resources:globalThis.__VeeamWebUiZhCatalog}'
    return text[:end] + zh_entry + text[end:]

plugin = patch_plugin_language_bundle(plugin_path.read_text(encoding='utf-8'), 'plugin.js')
vdp_plugin = patch_plugin_language_bundle(vdp_plugin_path.read_text(encoding='utf-8'), 'vdpPlugin.js')

def patch_extension_plugin_language_bundle(text: str, name: str, plugin_key: str) -> str:
    if 'iso:"zh-CN",title:"简体中文"' in text:
        raise SystemExit(name + ' already contains the Chinese extension language entry.')
    replacements = {
        'ahv': (
            'JWe=[jze,{iso:Roe.JA,title:"Japanese",flag:"",resources:UWe},Ywe,gPe]',
            'JWe=[jze,{iso:Roe.JA,title:"Japanese",flag:"",resources:UWe},Ywe,gPe,{iso:"zh-CN",title:"简体中文",flag:"",resources:((globalThis.__VeeamWebUiZhExtensionCatalog&&globalThis.__VeeamWebUiZhExtensionCatalog.ahv)||{})}]'
        ),
        'pve': (
            'cPe=[ICe,{iso:joe.JA,title:"Japanese",flag:"",resources:dPe},xke,qxe]',
            'cPe=[ICe,{iso:joe.JA,title:"Japanese",flag:"",resources:dPe},xke,qxe,{iso:"zh-CN",title:"简体中文",flag:"",resources:((globalThis.__VeeamWebUiZhExtensionCatalog&&globalThis.__VeeamWebUiZhExtensionCatalog.pve)||{})}]'
        ),
    }
    old, new = replacements[plugin_key]
    if old not in text:
        raise SystemExit('Expected extension language registry fragment was not found in ' + name + '.')
    return text.replace(old, new, 1)

ahv_plugin = patch_extension_plugin_language_bundle(ahv_plugin_path.read_text(encoding='utf-8'), 'AHV plugin.js', 'ahv')
pve_plugin = patch_extension_plugin_language_bundle(pve_plugin_path.read_text(encoding='utf-8'), 'PVE plugin.js', 'pve')

selector = login_selector_path.read_text(encoding='utf-8')
menu_block = """const menu = document.querySelector('.login-page-language-selector__menu');
        if (menu && !menu.querySelector('[data-veeam-zh-native="true"]')) {
            const templateItem = menu.querySelector('.login-page-language-selector__menu-item');
            if (templateItem) {
                const zhItem = templateItem.cloneNode(true);
                zhItem.dataset.veeamZhNative = 'true';
                zhItem.classList.remove('login-page-language-selector__menu-item--selected');
                zhItem.setAttribute('aria-selected', 'false');
                zhItem.querySelector('.login-page-language-selector__menu-item-text').textContent = '\\u7b80\\u4f53\\u4e2d\\u6587';
                zhItem.querySelector('input[name="Input.LanguageCode"]').value = 'zh-CN';
                menu.appendChild(zhItem);
            }
        }
        const menuItems = document.querySelectorAll('.login-page-language-selector__menu-item');"""

if 'data-veeam-zh-native' not in selector:
    menu_pattern = r"const menu = document\.querySelector\('\.login-page-language-selector__menu'\);\s*const menuItems = document\.querySelectorAll\('\.login-page-language-selector__menu-item'\);"
    selector, count = re.subn(menu_pattern, lambda _m: menu_block, selector, count=1, flags=re.S)
    if count != 1:
        raise SystemExit('Expected login language menu fragment was not found.')
else:
    raise SystemExit('An existing login-page Chinese selector patch was found. Uninstall the previous package or restore languageSelector.js before installing this package.')

if "localeCode === 'zh-CN'" not in selector:
    select_block = """if (localeCode === 'zh-CN') {
                localStorage.setItem('veeamWebUiZhNativeLocale', localeCode);
                localStorage.setItem('localization:language', JSON.stringify(localeCode));
                if (!isInitialization) {
                    window.location.assign('/');
                }
                return;
            }
            localStorage.removeItem('veeamWebUiZhNativeLocale');
            localStorage.setItem('localization:language', JSON.stringify(localeCode));

            if (isInitialization)
                return;

            // Submit the form to proceed with the changes on the server side"""
    select_pattern = r"if \(isInitialization\)\s*return;\s*// Submit the form to proceed with the changes on the server side"
    selector, count = re.subn(select_pattern, lambda _m: select_block, selector, count=1, flags=re.S)
    if count != 1:
        raise SystemExit('Expected login language handling fragment was not found.')

html = html.replace(module_tag, catalog_tag + '\n  ' + native_tag + '\n  ' + patched_module_tag)
with open(str(tmp_html), 'w', encoding='utf-8', newline='') as f:
    f.write(html)
with open(str(tmp_index), 'w', encoding='utf-8', newline='') as f:
    f.write(index)
with open(str(tmp_plugin), 'w', encoding='utf-8', newline='') as f:
    f.write(plugin)
with open(str(tmp_vdp_plugin), 'w', encoding='utf-8', newline='') as f:
    f.write(vdp_plugin)
with open(str(tmp_ahv_plugin), 'w', encoding='utf-8', newline='') as f:
    f.write(ahv_plugin)
with open(str(tmp_pve_plugin), 'w', encoding='utf-8', newline='') as f:
    f.write(pve_plugin)
with open(str(tmp_login_selector), 'w', encoding='utf-8', newline='') as f:
    f.write(selector)
PY

chown --reference="${HTML_PATH}" "${TMP_HTML}" 2>/dev/null || true
chmod --reference="${HTML_PATH}" "${TMP_HTML}" 2>/dev/null || true
chown --reference="${INDEX_PATH}" "${TMP_INDEX}" 2>/dev/null || true
chmod --reference="${INDEX_PATH}" "${TMP_INDEX}" 2>/dev/null || true
chown --reference="${PLUGIN_PATH}" "${TMP_PLUGIN}" 2>/dev/null || true
chmod --reference="${PLUGIN_PATH}" "${TMP_PLUGIN}" 2>/dev/null || true
chown --reference="${VDP_PLUGIN_PATH}" "${TMP_VDP_PLUGIN}" 2>/dev/null || true
chmod --reference="${VDP_PLUGIN_PATH}" "${TMP_VDP_PLUGIN}" 2>/dev/null || true
chown --reference="${AHV_PLUGIN_PATH}" "${TMP_AHV_PLUGIN}" 2>/dev/null || true
chmod --reference="${AHV_PLUGIN_PATH}" "${TMP_AHV_PLUGIN}" 2>/dev/null || true
chown --reference="${PVE_PLUGIN_PATH}" "${TMP_PVE_PLUGIN}" 2>/dev/null || true
chmod --reference="${PVE_PLUGIN_PATH}" "${TMP_PVE_PLUGIN}" 2>/dev/null || true
chown --reference="${LOGIN_SELECTOR_PATH}" "${TMP_LOGIN_SELECTOR}" 2>/dev/null || true
chmod --reference="${LOGIN_SELECTOR_PATH}" "${TMP_LOGIN_SELECTOR}" 2>/dev/null || true

install -m 0644 "${SOURCE_NATIVE_ASSET_PATH}" "${NATIVE_ASSET_PATH}"
install -m 0644 "${SOURCE_CATALOG_ASSET_PATH}" "${CATALOG_ASSET_PATH}"
chown --reference="${ASSETS_DIR}" "${NATIVE_ASSET_PATH}" "${CATALOG_ASSET_PATH}" 2>/dev/null || true

mv -f "${TMP_HTML}" "${HTML_PATH}"
mv -f "${TMP_INDEX}" "${INDEX_PATH}"
mv -f "${TMP_PLUGIN}" "${PLUGIN_PATH}"
mv -f "${TMP_VDP_PLUGIN}" "${VDP_PLUGIN_PATH}"
mv -f "${TMP_AHV_PLUGIN}" "${AHV_PLUGIN_PATH}"
mv -f "${TMP_PVE_PLUGIN}" "${PVE_PLUGIN_PATH}"
mv -f "${TMP_LOGIN_SELECTOR}" "${LOGIN_SELECTOR_PATH}"
trap - EXIT

PATCHED_HTML_SHA256="$(sha256_file "${HTML_PATH}")"
PATCHED_INDEX_SHA256="$(sha256_file "${INDEX_PATH}")"
PATCHED_PLUGIN_SHA256="$(sha256_file "${PLUGIN_PATH}")"
PATCHED_VDP_PLUGIN_SHA256="$(sha256_file "${VDP_PLUGIN_PATH}")"
PATCHED_AHV_PLUGIN_SHA256="$(sha256_file "${AHV_PLUGIN_PATH}")"
PATCHED_PVE_PLUGIN_SHA256="$(sha256_file "${PVE_PLUGIN_PATH}")"
PATCHED_LOGIN_SELECTOR_SHA256="$(sha256_file "${LOGIN_SELECTOR_PATH}")"
NATIVE_ASSET_SHA256="$(sha256_file "${NATIVE_ASSET_PATH}")"
CATALOG_ASSET_SHA256="$(sha256_file "${CATALOG_ASSET_PATH}")"

{
  printf 'BUILD=%q\n' "${BUILD}"
  printf 'WEB_ROOT=%q\n' "${WEB_ROOT}"
  printf 'HTML_PATH=%q\n' "${HTML_PATH}"
  printf 'INDEX_PATH=%q\n' "${INDEX_PATH}"
  printf 'PLUGIN_PATH=%q\n' "${PLUGIN_PATH}"
  printf 'VDP_PLUGIN_PATH=%q\n' "${VDP_PLUGIN_PATH}"
  printf 'AHV_PLUGIN_PATH=%q\n' "${AHV_PLUGIN_PATH}"
  printf 'PVE_PLUGIN_PATH=%q\n' "${PVE_PLUGIN_PATH}"
  printf 'LOGIN_SELECTOR_PATH=%q\n' "${LOGIN_SELECTOR_PATH}"
  printf 'NATIVE_ASSET_PATH=%q\n' "${NATIVE_ASSET_PATH}"
  printf 'CATALOG_ASSET_PATH=%q\n' "${CATALOG_ASSET_PATH}"
  printf 'BACKUP_HTML_PATH=%q\n' "${BACKUP_HTML_PATH}"
  printf 'BACKUP_INDEX_PATH=%q\n' "${BACKUP_INDEX_PATH}"
  printf 'BACKUP_PLUGIN_PATH=%q\n' "${BACKUP_PLUGIN_PATH}"
  printf 'BACKUP_VDP_PLUGIN_PATH=%q\n' "${BACKUP_VDP_PLUGIN_PATH}"
  printf 'BACKUP_AHV_PLUGIN_PATH=%q\n' "${BACKUP_AHV_PLUGIN_PATH}"
  printf 'BACKUP_PVE_PLUGIN_PATH=%q\n' "${BACKUP_PVE_PLUGIN_PATH}"
  printf 'BACKUP_LOGIN_SELECTOR_PATH=%q\n' "${BACKUP_LOGIN_SELECTOR_PATH}"
  printf 'ORIGINAL_HTML_SHA256=%q\n' "${HTML_SHA256}"
  printf 'ORIGINAL_INDEX_SHA256=%q\n' "${INDEX_SHA256}"
  printf 'ORIGINAL_PLUGIN_SHA256=%q\n' "${PLUGIN_SHA256}"
  printf 'ORIGINAL_VDP_PLUGIN_SHA256=%q\n' "${VDP_PLUGIN_SHA256}"
  printf 'ORIGINAL_AHV_PLUGIN_SHA256=%q\n' "${AHV_PLUGIN_SHA256}"
  printf 'ORIGINAL_PVE_PLUGIN_SHA256=%q\n' "${PVE_PLUGIN_SHA256}"
  printf 'ORIGINAL_LOGIN_SELECTOR_SHA256=%q\n' "${LOGIN_SELECTOR_SHA256}"
  printf 'PATCHED_HTML_SHA256=%q\n' "${PATCHED_HTML_SHA256}"
  printf 'PATCHED_INDEX_SHA256=%q\n' "${PATCHED_INDEX_SHA256}"
  printf 'PATCHED_PLUGIN_SHA256=%q\n' "${PATCHED_PLUGIN_SHA256}"
  printf 'PATCHED_VDP_PLUGIN_SHA256=%q\n' "${PATCHED_VDP_PLUGIN_SHA256}"
  printf 'PATCHED_AHV_PLUGIN_SHA256=%q\n' "${PATCHED_AHV_PLUGIN_SHA256}"
  printf 'PATCHED_PVE_PLUGIN_SHA256=%q\n' "${PATCHED_PVE_PLUGIN_SHA256}"
  printf 'PATCHED_LOGIN_SELECTOR_SHA256=%q\n' "${PATCHED_LOGIN_SELECTOR_SHA256}"
  printf 'NATIVE_ASSET_SHA256=%q\n' "${NATIVE_ASSET_SHA256}"
  printf 'CATALOG_ASSET_SHA256=%q\n' "${CATALOG_ASSET_SHA256}"
  printf 'INSTALLED_AT=%q\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
} > "${MANIFEST_PATH}"
chmod 0600 "${MANIFEST_PATH}"

echo "Veeam Web UI Simplified Chinese package installed."
echo "Hard-refresh the browser, then select Simplified Chinese from the language menu."
