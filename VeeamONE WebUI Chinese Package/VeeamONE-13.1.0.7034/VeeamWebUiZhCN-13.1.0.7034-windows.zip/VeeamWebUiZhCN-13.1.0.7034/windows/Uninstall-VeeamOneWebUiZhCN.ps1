[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Assert-Administrator {
    $principal = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList ([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Run this script from an elevated PowerShell session.'
    }
}

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Restart-VeeamOneReporterService {
    $service = Get-Service -Name 'VeeamRSS' -ErrorAction Stop
    if ($service.Status -ne [System.ServiceProcess.ServiceControllerStatus]::Running) {
        Write-Warning "Veeam ONE Reporting Service is not running ($($service.Status)). Start VeeamRSS manually before testing the UI."
        return
    }
    try {
        Restart-Service -Name 'VeeamRSS' -Force -ErrorAction Stop
        $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(60))
        Write-Host 'Restarted Veeam ONE Reporting Service (VeeamRSS).'
    }
    catch {
        Write-Warning 'Veeam ONE Reporting Service restart failed. Restart VeeamRSS manually before testing the UI.'
    }
}

function Restore-OriginalHtml([string]$HtmlPath, [string]$BackupHtmlPath, [string]$ExpectedHash) {
    $tempHtml = "$HtmlPath.veeam-zh-cn-restore"
    Copy-Item -LiteralPath $BackupHtmlPath -Destination $tempHtml -Force
    Move-Item -LiteralPath $tempHtml -Destination $HtmlPath -Force
    if ((Get-Sha256 $HtmlPath) -ne $ExpectedHash) {
        throw 'Restored Veeam ONE HTML hash is unexpected. Keep the backup directory and stop.'
    }
}

Assert-Administrator

$build = '13.1.0.7034'
$programFiles = $env:ProgramFiles
$programData = $env:ProgramData
$assetRoot = Join-Path $programFiles 'Veeam\Veeam ONE\Veeam ONE Reporter Server\Assets'
$htmlPath = Join-Path $assetRoot 'index.html'
$staticJsRoot = Join-Path $assetRoot 'static\js'
$mainPath = Join-Path $staticJsRoot 'main.1c26fdf6.js'
$pluginPath = Join-Path $assetRoot 'plugin\plugin.js'
$backupRoot = Join-Path $programData "VeeamWebUiZhCN\VeeamONE-$build"
$backupHtmlPath = Join-Path $backupRoot 'index.html.original'
$backupPluginPath = Join-Path $backupRoot 'plugin.js.original'
$manifestPath = Join-Path $backupRoot 'manifest.json'

if (-not (Test-Path -LiteralPath $manifestPath) -or -not (Test-Path -LiteralPath $backupHtmlPath)) {
    throw 'Package backup or manifest was not found. No files were changed.'
}

$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json

if ($manifest.PackageSchema -eq 3) {
    if (($manifest.GeneratedCatalogFileName -notmatch '^[A-Za-z0-9._-]+$') -or
        ($manifest.GeneratedMainFileName -notmatch '^[A-Za-z0-9._-]+$')) {
        throw 'Package manifest has unexpected generated asset names. No files were changed.'
    }
    $generatedCatalogPath = Join-Path $staticJsRoot $manifest.GeneratedCatalogFileName
    $generatedMainPath = Join-Path $staticJsRoot $manifest.GeneratedMainFileName
    if ((Get-Sha256 $htmlPath) -ne $manifest.PatchedHtmlSha256 -or
        (Get-Sha256 $pluginPath) -ne $manifest.PatchedPluginSha256 -or
        -not (Test-Path -LiteralPath $generatedCatalogPath) -or
        (Get-Sha256 $generatedCatalogPath) -ne $manifest.GeneratedCatalogSha256 -or
        -not (Test-Path -LiteralPath $generatedMainPath) -or
        (Get-Sha256 $generatedMainPath) -ne $manifest.GeneratedMainSha256) {
        throw 'Current Veeam ONE files were not written by this package. The server may have been upgraded or modified. No files were changed.'
    }
    if ((Get-Sha256 $backupHtmlPath) -ne $manifest.OriginalHtmlSha256 -or
        (Get-Sha256 $mainPath) -ne $manifest.OriginalMainSha256 -or
        -not (Test-Path -LiteralPath $backupPluginPath) -or
        (Get-Sha256 $backupPluginPath) -ne $manifest.OriginalPluginSha256) {
        throw 'The backup or original main-file hash is unexpected. No files were changed.'
    }

    Restore-OriginalHtml $htmlPath $backupHtmlPath $manifest.OriginalHtmlSha256
    $tempPlugin = "$pluginPath.veeam-zh-cn-restore"
    Copy-Item -LiteralPath $backupPluginPath -Destination $tempPlugin -Force
    Move-Item -LiteralPath $tempPlugin -Destination $pluginPath -Force
    if ((Get-Sha256 $pluginPath) -ne $manifest.OriginalPluginSha256) {
        throw 'Restored Veeam ONE plugin hash is unexpected. Keep the backup directory and stop.'
    }
    Remove-Item -LiteralPath $generatedMainPath -Force
    Remove-Item -LiteralPath $generatedCatalogPath -Force

    if ((Test-Path -LiteralPath $generatedMainPath) -or
        (Test-Path -LiteralPath $generatedCatalogPath)) {
        throw 'Generated Veeam ONE Chinese assets could not be removed. Keep the backup directory and stop.'
    }
}
elseif ($manifest.PackageSchema -eq 2) {
    # Supports the first 13.1.0.7034 package layout so it can be safely removed before this cache-safe layout is installed.
    $legacyBackupMainPath = Join-Path $backupRoot 'main.1c26fdf6.js.original'
    $legacyCatalogPath = Join-Path $staticJsRoot 'veeam-one-zh-CN-catalog.js'
    $legacyBackupCatalogPath = Join-Path $backupRoot 'veeam-one-zh-CN-catalog.js.original'
    if (-not (Test-Path -LiteralPath $legacyBackupMainPath) -or
        (Get-Sha256 $htmlPath) -ne $manifest.PatchedHtmlSha256 -or
        (Get-Sha256 $mainPath) -ne $manifest.PatchedMainSha256 -or
        -not (Test-Path -LiteralPath $legacyCatalogPath) -or
        (Get-Sha256 $legacyCatalogPath) -ne $manifest.CatalogAssetSha256) {
        throw 'Current Veeam ONE files were not written by the previous package layout. No files were changed.'
    }
    if ((Get-Sha256 $backupHtmlPath) -ne $manifest.OriginalHtmlSha256 -or
        (Get-Sha256 $legacyBackupMainPath) -ne $manifest.OriginalMainSha256) {
        throw 'The previous package backup hashes are unexpected. No files were changed.'
    }
    if ($manifest.OriginalCatalogPresent -and
        (-not (Test-Path -LiteralPath $legacyBackupCatalogPath) -or
         (Get-Sha256 $legacyBackupCatalogPath) -ne $manifest.OriginalCatalogSha256)) {
        throw 'The previous package catalog backup hash is unexpected. No files were changed.'
    }

    $tempMain = "$mainPath.veeam-zh-cn-restore"
    Copy-Item -LiteralPath $legacyBackupMainPath -Destination $tempMain -Force
    Restore-OriginalHtml $htmlPath $backupHtmlPath $manifest.OriginalHtmlSha256
    Move-Item -LiteralPath $tempMain -Destination $mainPath -Force
    if ($manifest.OriginalCatalogPresent) {
        $tempCatalog = "$legacyCatalogPath.veeam-zh-cn-restore"
        Copy-Item -LiteralPath $legacyBackupCatalogPath -Destination $tempCatalog -Force
        Move-Item -LiteralPath $tempCatalog -Destination $legacyCatalogPath -Force
    }
    else {
        Remove-Item -LiteralPath $legacyCatalogPath -Force
    }
    if ((Get-Sha256 $mainPath) -ne $manifest.OriginalMainSha256 -or
        ($manifest.OriginalCatalogPresent -and (Get-Sha256 $legacyCatalogPath) -ne $manifest.OriginalCatalogSha256) -or
        (-not $manifest.OriginalCatalogPresent -and (Test-Path -LiteralPath $legacyCatalogPath))) {
        throw 'Restored Veeam ONE legacy package files have unexpected hashes. Keep the backup directory and stop.'
    }
}

Restart-VeeamOneReporterService
Remove-Item -LiteralPath $backupRoot -Recurse -Force
Write-Host 'Veeam ONE Simplified Chinese package uninstalled. Original file hashes were verified.' -ForegroundColor Green
